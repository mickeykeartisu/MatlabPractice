%%  Design quadrature mirror filter
%   by Hideki Kawahara
%   12/July/2008

fs = 22050; % This is only an example.
boundaryFq = fs/4;
transitionWidth = 1/4;
levelTolerancePassBand = 0.1; % 4% fluctuation
levelToleranceStopBand = 0.002; % -60 dB
mags = [0 1];
fcuts = boundaryFq*2.0.^(transitionWidth*[-1 1]);
devs = [levelToleranceStopBand levelTolerancePassBand];
cutOffShift = 1/17.3;

[nTapsHP,WnHP,betaHP,ftypeHP] = ...
    kaiserord(fcuts*2.0.^(-cutOffShift),mags,devs,fs);

[nTapsLP,WnLP,betaLP,ftypeLP] = ...
    kaiserord(fcuts*2.0.^(cutOffShift),mags(end:-1:1),devs(end:-1:1),fs);

hLP = fir1(nTapsLP,WnLP,ftypeLP,kaiser(nTapsLP+1,betaLP),'noscale');

hHP = fir1(nTapsHP,WnHP,ftypeHP,kaiser(nTapsHP+1,betaHP),'noscale');

save setQMFv1 hLP hHP

%%  Test event detection
%   24/Nov./2007

%fs
%x
%f0

baseMeanTime = mean(w.*(0:length(w)-1)')/mean(w);
baseDuration = ...
    sqrt(mean((w.*((0:length(w)-1)'-baseMeanTime)).^2)/mean(w.^2))/length(w);
baseDurationInS = baseDuration/fs*length(w);

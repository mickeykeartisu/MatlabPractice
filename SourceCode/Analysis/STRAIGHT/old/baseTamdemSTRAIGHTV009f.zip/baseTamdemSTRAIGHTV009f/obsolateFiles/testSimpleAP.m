%%  Test aperiodicity
%   13/Nov./2007

%%  generate signal

fs = 44100;
f0 = 100;
tt = 0:1/fs:1;
x = tt'*0;
x(round(1:fs/f0:end)) = 1;

%%  design time window

basePeriod = fs/f0;
w = blackman(round(basePeriod*6)+1);
baseIndex = (1:length(w))-round((length(w)-1)/2);

%%  Simulate signal with noise

relativeNoiseLevel = 0.0001;
periodicRMS = std(x);
randomRMS = periodicRMS*relativeNoiseLevel;

fftl = 2^ceil(log2(length(baseIndex))+1);
simulatedSignal = x+randn(length(x),1)*randomRMS;
f0BinWidth = f0/fs*fftl;

numberOfSamples = 1000;
meanBottomLevelsVector = zeros(numberOfSamples,2);
aperiodicPower = zeros(numberOfSamples,2);
doubleFrequency = ([-fftl+2:0 1:fftl]'-0.5)/fftl*fs;
for jj = 1:numberOfSamples;
    currentTime = 0.25+0.5*rand;
    currentIndex = round(currentTime*fs);

    powerSpectrum1 = abs(fft(w.*simulatedSignal(currentIndex+baseIndex),fftl)).^2;
    doubleSpectrum = [powerSpectrum1(end:-1:2); powerSpectrum1];
    cumlativePower = cumsum(doubleSpectrum);
    upperSpectrum = interp1(doubleFrequency,cumlativePower,(0:fftl/2)/fftl*fs+f0/2);
    lowerSpectrum = interp1(doubleFrequency,cumlativePower,(0:fftl/2)/fftl*fs-f0/2);
    spectrumSTRAIGHT = (upperSpectrum-lowerSpectrum)/f0BinWidth;
    semiupperSpectrum = interp1(doubleFrequency,cumlativePower,(0:fftl/2)/fftl*fs+f0/4);
    semilowerSpectrum = interp1(doubleFrequency,cumlativePower,(0:fftl/2)/fftl*fs-f0/4);
    semispectrumSTRAIGHT = (semiupperSpectrum-semilowerSpectrum)/f0BinWidth;
    diffSpectrum1 = diff([semispectrumSTRAIGHT semispectrumSTRAIGHT(end)]);
    diffSpectrum2 = diff([semispectrumSTRAIGHT(1) semispectrumSTRAIGHT]);
    bottomIndicator = diffSpectrum1.*diffSpectrum2.*(diffSpectrum1>diffSpectrum2);
    normalizedSpectrum = powerSpectrum1(1:fftl/2+1)./spectrumSTRAIGHT';
    aperiodicPower(jj,1) = mean(powerSpectrum1(mm<0))/mean(powerSpectrum1);
    aperiodicPower(jj,2) = mean(powerSpectrum1(mm<0));

    %  check for bottom levels


    bottomLevels = zeros(length(1:f0BinWidth:fftl/2-f0BinWidth),1);
    ii = 1;
    for lowerBound = 1:f0BinWidth:fftl/2-f0BinWidth
        bottomLevels(ii) = min(normalizedSpectrum(round((1:f0BinWidth)+(lowerBound-1))));
        ii = ii+1;
    end;

    averageBottomLevels = sqrt(mean(bottomLevels));
    meanBottomLevelsVector(jj,1) = averageBottomLevels;
    meanBottomLevelsVector(jj,2) = sqrt(mean(powerSpectrum1));
end;

%%  Check statistical results

figure;hist(meanBottomLevelsVector(:,1))
figure;hist(meanBottomLevelsVector(:,2))

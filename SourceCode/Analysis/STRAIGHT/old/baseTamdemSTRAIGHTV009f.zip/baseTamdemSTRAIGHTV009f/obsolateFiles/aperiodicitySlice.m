function outputStructure = aperiodicitySlice(x,fs,f0,tc,w,shaper)

baseIndex = (1:length(w))-(length(w)-1)/2;
tx = x(max(1,min(length(x),round(tc*fs+1)+baseIndex)));
fftl = length(w)+1;
powerSpectrum1 = abs(fft(tx,fftl)).^2;
autoCorrelation1 = ifft(powerSpectrum1);
smoothedSpectrum = real(ifft(autoCorrelation1.*shaper));
diffSpectrum1 = diff([smoothedSpectrum; smoothedSpectrum(end)]);
diffSpectrum2 = diff([smoothedSpectrum(1); smoothedSpectrum]);
bottomIndicator = diffSpectrum1.*diffSpectrum2.*(diffSpectrum1>diffSpectrum2);
peakIndicator = diffSpectrum1.*diffSpectrum2.*(diffSpectrum1<diffSpectrum2);
outputStructure.aperiodicityPower = mean(powerSpectrum1(bottomIndicator<0))/mean(powerSpectrum1);
outputStructure.bottoms = powerSpectrum1(bottomIndicator<0);
outputStructure.peaks = powerSpectrum1(peakIndicator<0);
outputStructure.rms = std(tx.*w);
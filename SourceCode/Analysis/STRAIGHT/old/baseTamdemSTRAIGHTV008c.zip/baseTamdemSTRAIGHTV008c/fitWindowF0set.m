function [f0,w,shaper] = fitWindowF0set(f0in,fs)
%   Internal function for fitting fs,f0 and window size
%   for aperiodicity calculation
%   [f0,w] = fitWindowF0set(f0,fs)
%   f0in    : initial fundamental frequency (Hz)
%   fs      : sampling frequency (Hz)

%   Designed and coded by Hideki Kawahara
%   17/Nov./2007

nCycles = 4;
tentativePeriod = fs/f0in*nCycles;
fftl = 2^round(log2(tentativePeriod));%+1);
tentativePeriod = round(fftl/nCycles);
f0 = fs/tentativePeriod;
w = hanning(fftl-1);
basePeriod = fs/f0;
shaper = zeros(fftl,1);
shaper(1:round(2*basePeriod)) = ...
    0.5+0.5*cos(((1:round(2*basePeriod))-basePeriod)/basePeriod*pi)';
shaper(end:-1:fftl/2+1) = shaper(1:fftl/2);


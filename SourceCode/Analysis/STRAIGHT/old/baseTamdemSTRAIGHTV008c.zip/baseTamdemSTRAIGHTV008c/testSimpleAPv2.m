%%  Test aperiodicity
%   13/Nov./2007
%   17/Nov./2007

%%  generate signal

fs = 44100;
f0 = 40;
tentativePeriod = fs/f0;
f0 = fs/round(tentativePeriod);
tt = 0:1/fs:1;
x = tt'*0;
x(round(1:fs/f0:end)) = 1;

%%  design time window

basePeriod = fs/f0;
w = blackman(round(basePeriod*5)+1);
baseIndex = (1:length(w))-round((length(w)-1)/2);

%%  Simulate signal with noise

relativeNoiseLevelList = 10.0.^(-(0:5:60)/20);
aperiodicityPowerLevels = zeros(length(relativeNoiseLevelList),2);

for ii = 1:length(relativeNoiseLevelList)

    relativeNoiseLevel = relativeNoiseLevelList(ii);
    periodicRMS = std(x);
    randomRMS = periodicRMS*relativeNoiseLevel;

    fftl = 2^ceil(log2(length(baseIndex))+1);
    simulatedSignal = x+randn(length(x),1)*randomRMS;
    f0BinWidth = f0/fs*fftl;
    shaper = zeros(fftl,1);
    shaper(1:round(2*basePeriod)) = ...
        0.5+0.5*cos(((1:round(2*basePeriod))-basePeriod)/basePeriod*pi)';
    shaper(end:-1:fftl/2+1) = shaper(1:fftl/2);

    numberOfSamples = 1000;
    meanBottomLevelsVector = zeros(numberOfSamples,2);
    aperiodicPower = zeros(numberOfSamples,2);
    doubleFrequency = ([-fftl+2:0 1:fftl]'-0.5)/fftl*fs;
    tic
    for jj = 1:numberOfSamples;
        currentTime = 0.25+0.5*rand;
        currentIndex = round(currentTime*fs);

        powerSpectrum1 = abs(fft(w.*simulatedSignal(currentIndex+baseIndex),fftl)).^2;
        autoCorrelation1 = ifft(powerSpectrum1);
        smoothedSpectrum = real(ifft(autoCorrelation1.*shaper));
        diffSpectrum1 = diff([smoothedSpectrum; smoothedSpectrum(end)]);
        diffSpectrum2 = diff([smoothedSpectrum(1); smoothedSpectrum]);
        bottomIndicator = diffSpectrum1.*diffSpectrum2.*(diffSpectrum1>diffSpectrum2);
        aperiodicPower(jj,1) = mean(powerSpectrum1(bottomIndicator<0))/mean(powerSpectrum1);
        aperiodicPower(jj,2) = mean(powerSpectrum1(bottomIndicator<0));
    end;
    toc;
    aperiodicityPowerLevels(ii,:) = mean(aperiodicPower);
    disp([num2str(relativeNoiseLevel) '   '...
        num2str(aperiodicityPowerLevels(ii,1)) ...
        '   ' num2str(aperiodicityPowerLevels(ii,2))])
end;

%%  Check statistical results

figure;
plot(20*log10(relativeNoiseLevelList),10*log10(aperiodicityPowerLevels(:,1)));
grid on;

noiseLevelsIndB = 20*log10(relativeNoiseLevelList);
relativeNoiseIndB = 20*log10(relativeNoiseLevelList./...
    sqrt(1+relativeNoiseLevelList.^2));
observedRelativeNoiseIndB = 10*log10(aperiodicityPowerLevels(:,1));

figure;
plot(relativeNoiseIndB,observedRelativeNoiseIndB);grid on;


function spectrumParamter = exSpectrumTSTRAIGHTGB(x,fs,sourceObj,paramsIn)
%   Spectrum extraction based on TANDEM-STRAIGHT
%   spectrumParamter = exSpectrumTSTRAIGHTGB(x,fs,sourceObj,paramsIn)
%
%   Inputs
%       x   : input signal
%       fs  : sampling frequency
%       sourceObj   : source information object
%   Outputs
%       spectrumParameter   : spectum infromation output structure
%

%   Designed and coded by Hideki Kawahara
%   31/Oct./2007


%---- set default parameters
framePeriod = 5; % in ms
f0lowLimit = 70;
optionalParameter.q1 = -0.2;
optionalParameter.DCremoval = 0;
outputTANDEMspectrum = 1;

%---- check for input parameters
if nargin > 2
    temporalPositions = 0:framePeriod/1000:length(x)/fs;
    if ~isfield(sourceObj,'f0')
        error('no F0 information in sourceObject')
    else
        f0Sequence = sourceObj.f0;
    end;
    if isfield(sourceObj,'temporalPositions')
        temporalPositions = sourceObj.temporalPositions;
    end;
end;
if nargin > 3
    if isfield(paramsIn,'f0lowLimit')
        f0lowLimit = paramsIn.f0lowLimit;
    end;
    if isfield(paramsIn,'compensationCoefficient')
        optionalParameter.q1 = paramsIn.compensationCoefficient;
    end;
    if isfield(paramsIn,'FFTsize')
        optionalParameter.FFTsize = paramsIn.FFTsize;
    end;
    if isfield(paramsIn,'outputTANDEMspectrum')
        outputTANDEMspectrum = paramsIn.outputTANDEMspectrum;
    end;
end;
analysisConditions.f0lowLimit = f0lowLimit;
analysisConditions.compensationCoefficient = optionalParameter.q1;
analysisConditions.outputTANDEMspectrum = outputTANDEMspectrum;
analysisConditions.DCremoval = 0;
spetrumParamter.analysisConditions = analysisConditions;
if nargin == 0
    return;
end;

%---- STRAIGHT spectral analysis body

tSTRAIGHTresults = TandemSTRAIGHTGeneralBody(x,fs,f0Sequence(1),...
    temporalPositions(1),f0lowLimit,optionalParameter);

spectrogramSTRAIGHT = ...
    zeros(size(tSTRAIGHTresults.sliceSTRAIGHT,1),length(f0Sequence));
if outputTANDEMspectrum
    spectrogramTANDEM = spectrogramSTRAIGHT;
end
tic;
for ii = 1:length(f0Sequence);
    currentTime = temporalPositions(ii);
    tSTRAIGHTresults = TandemSTRAIGHTGeneralBody(x,fs,f0Sequence(ii),...
        currentTime,f0lowLimit,optionalParameter);
    spectrogramSTRAIGHT(:,ii) = tSTRAIGHTresults.sliceSTRAIGHT;
    if outputTANDEMspectrum
        spectrogramTANDEM(:,ii) = tSTRAIGHTresults.sliceTANDEM;
    end;
end;
ElapsedTimeForSpectrum = toc;

%---- output parameters
spectrumParamter.ElapsedTimeForSpectrum = ElapsedTimeForSpectrum;
spectrumParamter.temporalPositions = temporalPositions;
spectrumParamter.spectrogramSTRAIGHT = spectrogramSTRAIGHT;
spectrumParamter.samplingFrequency = fs;
spectrumParamter.TANDEMSTRAIGHTconditions = tSTRAIGHTresults.analysisConditions;
if outputTANDEMspectrum
    spectrumParamter.spectrogramTANDEM = spectrogramTANDEM;
end;
spectrumParamter.dateOfSpectrumEstimation = datestr(now);


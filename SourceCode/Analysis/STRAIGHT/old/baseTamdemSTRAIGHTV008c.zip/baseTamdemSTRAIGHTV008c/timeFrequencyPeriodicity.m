function periodicityStructure = ...
    timeFrequencyPeriodicity(x,fs,f0Structure,optionalParams)
%   Periodicity map estimation
%   function periodicityStructure = ...
%       timeFrequencyPeriodicity(x,fs,f0Structure,optionalParams)

%   Designed and coded by Hideki Kawahara
%   16/Dec./2007

%%   Initialize input parameters
periodicityStructure = f0Structure;
tempF0sequence = f0Structure.f0;
temporalPositions = f0Structure.temporalPositions;
f0floor = f0Structure.controlParameters.f0floor;
f0ceil = f0Structure.controlParameters.f0ceil;
framePeriod = f0Structure.controlParameters.framePeriod;
f0CandidatesScore = f0Structure.f0CandidatesScoreMap(1,:);

defaultF0 = 40;
targetF0 = 55;
biasInsmoothing = 3; % set smoothing size
nCycles = 14;
F0JumpLimit = 0.0420; % relative 3*std(diff) to mean F0
thresholdForVoicing = 1.2; 

if nargin == 4
    if isfield(optionalParams, 'nCyclesForAP')
        nCycles = optionalParams.nCyclesForAP;
    end;
    if isfield(optionalParams, 'biasInsmoothing')
        biasInsmoothing = optionalParams.biasInsmoothing;
    end;
end;

%%  Adjuat internal parameters

tempF0sequence(tempF0sequence == 0) = defaultF0;
tempF0sequence(tempF0sequence <f0floor) = f0floor;
tempF0sequence(tempF0sequence >f0ceil*2) = f0ceil;
tempF0sequence(tempF0sequence >fs/2) = f0ceil;

f0inSamplingRate = interp1(temporalPositions,tempF0sequence, ...
    (0:length(x)-1)/fs,'linear','extrap');
originalPhase = cumsum(2*pi*f0inSamplingRate/fs);
PhaseForConstantF0 = 2*pi*targetF0/fs* ...
    cumsum(ones(ceil(originalPhase(end)/(2*pi*targetF0/fs)),1));
constantF0Signal = interp1(originalPhase,x,PhaseForConstantF0,'linear','extrap');
originalTimeInSamplingRate = interp1(originalPhase,(0:length(originalPhase)-1)/fs, ...
    PhaseForConstantF0,'linear','extrap');
temporalPositionsOnNewTime = interp1(originalTimeInSamplingRate,...
    (0:length(originalTimeInSamplingRate)-1)/fs,temporalPositions,'linear','extrap');

%% ----extract aperiodicity parameter

%nCycles = 14;
currentNewTime = 0;
[ap,statusParamsAP] = ...
    TANDEMAPGB(constantF0Signal,fs,targetF0,currentNewTime,nCycles);
frequencyAxisLength = length(statusParamsAP.normalizedSpectrum);
periodicitySpectrum = zeros(frequencyAxisLength,length(temporalPositionsOnNewTime));
fftl = (frequencyAxisLength-1)*2;
frequencyAxis = (0:frequencyAxisLength-1)'/fftl*fs;
newFrequencyAxisLength = length(statusParamsAP.normalizedSpectrum);
aperiodicityMap = zeros(length(frequencyAxis),length(temporalPositionsOnNewTime));
quadratureSignal = statusParamsAP.quadratureSignal;

STRAIGHTprev2 = sqrt(statusParamsAP.sliceSTRAIGHT);
STRAIGHTprev1 = STRAIGHTprev2;
previousF0 = tempF0sequence(1);
previousF02 = previousF0;
spectralDeviationsMap = zeros(length(ap),length(temporalPositionsOnNewTime));
tic;
for ii = 1:length(temporalPositionsOnNewTime)
    currentNewTime = temporalPositionsOnNewTime(ii);
    currentF0 = tempF0sequence(ii);
    [ap,statusParamsAP] = ...
        TANDEMAPGB(constantF0Signal,fs,targetF0,currentNewTime,nCycles);
    periodicitySpectrum(:,ii) = statusParamsAP.normalizedSpectrum;
    sliceSTRAIGHT = sqrt(statusParamsAP.sliceSTRAIGHT);
    localF0trajectory = [previousF02 previousF0 currentF0];
    if (std(localF0trajectory)/mean(localF0trajectory) > F0JumpLimit) ...
            || (sum(f0CandidatesScore(max(1,ii+(-2:0))) < thresholdForVoicing))
        spectralDeviationsMap(:,max(1,ii-1)) = sliceSTRAIGHT*0;
    else
        diff2 = (STRAIGHTprev2-STRAIGHTprev1)./(STRAIGHTprev2+STRAIGHTprev1);
        diff1 = (sliceSTRAIGHT-STRAIGHTprev1)./(STRAIGHTprev1+sliceSTRAIGHT);
        diffActual = diff2-diff1;
        newFrequencyAxis = ...
            (0:length(ap)-1)'/2/(newFrequencyAxisLength-1)*fs/targetF0*currentF0;
        aperiodicityMap(:,ii) = ...
            min(1,interp1H(newFrequencyAxis,ap,frequencyAxis,'linear',ap(end)))';
        prevFrequencyAxis = ...
            (0:length(diff2)-1)'/2/(newFrequencyAxisLength-1)*fs/targetF0*previousF0;
        diffNormal = ...
            interp1H(prevFrequencyAxis,diffActual,frequencyAxis,'linear',ap(end));
        tmpCorrection = (diffNormal-mean(diffNormal)).^2;
        spectralDeviationsMap(:,max(1,ii-1)) = tmpCorrection;
    end;
    spectralDeviationsMap(:,ii) = spectralDeviationsMap(:,max(1,ii-1));
    STRAIGHTprev2 = STRAIGHTprev1;
    STRAIGHTprev1 = sliceSTRAIGHT;
    previousF02 = previousF0;
    previousF0 = currentF0;
end;
elapsedTimeForAperiodicity = toc;

%%  smoothing output data
nSmoothing = biasInsmoothing*2-1;

temporallySmoothedMap = ...
    sqrt(fftfilt(ones(nSmoothing,1)/nSmoothing,...
    [aperiodicityMap zeros(size(aperiodicityMap,1),biasInsmoothing)]'.^2))';
temporallySmoothedMap = temporallySmoothedMap(:,biasInsmoothing+1:end);

%%  Calibrate raw data using pre-compiled simulation data

% load calibration table
if sscanf(version('-release'), '%d') < 2006
    load calibrationForAPV6
else
    load calibrationForAP
end;

CP = (0.56402*0.7)^2; % 0.7 is a magic number
[xx,yy,zz] = meshgrid(smoothingTable,nCycleTable,framePeriodTable);
CR = (interp3(xx,yy,zz,calibrationTableForCRmean, ...
    nSmoothing,nCycles,framePeriod)*1.3)^2; % 1.3 is a magic number

alpha = 20;
b1 = 0; b2 = 1;
QC = temporallySmoothedMap.^2;
xx = (QC-CR)/(CP-CR);
y=(log((1+exp(-alpha*(xx-b1)))./(1+exp(-alpha*(xx-b2)))))/alpha+b2;
amplitudePeriodic = sqrt(abs(y));

xx = (CP-QC)/(CP-CR);
y=(log((1+exp(-alpha*(xx-b1)))./(1+exp(-alpha*(xx-b2)))))/alpha+b2;
amplitudeRandom = sqrt(abs(y));

%%  Copy results to output structure

periodicityStructure.dateOfAPExtraction = datestr(now);
periodicityStructure.elapsedTimeForAperiodicity = elapsedTimeForAperiodicity;
periodicityStructure.amplitudePeriodic = amplitudePeriodic;
periodicityStructure.spectralDeviationsMap = spectralDeviationsMap;
periodicityStructure.amplitudeRandom = amplitudeRandom;
periodicityStructure.aperiodicityMap = aperiodicityMap;
periodicityStructure.temporallySmoothedMap = temporallySmoothedMap;
periodicityStructure.statusParamsAP = statusParamsAP;

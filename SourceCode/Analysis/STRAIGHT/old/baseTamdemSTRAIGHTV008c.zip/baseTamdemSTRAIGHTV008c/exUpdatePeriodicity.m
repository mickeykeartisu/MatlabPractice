function revisedSource = exUpdatePeriodicity(sourceObj,spectrumObj)

%%  Copy information

revisedSource = sourceObj;

f0 = sourceObj.f0;
fs = sourceObj.samplingFrequency;
tLocations = sourceObj.temporalPositions;
f0LowLimit = sourceObj.controlParameters.f0floor;
if sum(f0<f0LowLimit) > 0
    f0(f0<f0LowLimit) = f0LowLimit;
end;
spectrumSTRAIGHT = spectrumObj.spectrogramSTRAIGHT;
%absSTRAIGHT = sqrt(spectrumSTRAIGHT);
aperiodicityMap = sourceObj.aperiodicityMap;
fftl = (size(spectrumSTRAIGHT,1)-1)*2;
fftlAP = (size(aperiodicityMap,1)-1)*2;
fx = (0:fftl/2)'/fftl*fs;
fx(fftl/2+2:fftl) = -fx(fftl/2:-1:2);
nCyclesForAP = sourceObj.controlParameters.nCyclesForAP;
biasInsmoothing = sourceObj.controlParameters.biasInsmoothingForAP;
nSmoothing = biasInsmoothing*2-1;

%%  Calculate TANDEM center locations and interpolate

tic;
t0 = 1.0./f0;
tLocationsPre = tLocations-t0'/2;
tLocationsPost = tLocations+t0'/2;
%deltaSTRAIGHT = ...
%    interp1(tLocations,absSTRAIGHT',tLocationsPost,'linear','extrap')' ...
%    - interp1(tLocations,absSTRAIGHT',tLocationsPre,'linear','extrap')';
preSpectrumTmp = ...
    interp1(tLocations,spectrumSTRAIGHT',tLocationsPre,'linear','extrap')';
postSpectrumTmp = ...
    interp1(tLocations,spectrumSTRAIGHT',tLocationsPost,'linear','extrap')';
deltaSTRAIGHT = postSpectrumTmp-preSpectrumTmp;
normalizedDeltaSTRAIGHT = 2*abs(deltaSTRAIGHT)./(postSpectrumTmp+preSpectrumTmp);
doubleNormalizedDeltaSTRAIGHT = [normalizedDeltaSTRAIGHT; ...
    normalizedDeltaSTRAIGHT(end-1:-1:2,:)];
toc

%%  Spectrum difference for all locations

tic;
shapedDeltaSTRAIGHT = deltaSTRAIGHT*0;
numberOfLocations = length(tLocations);
maxJumpInOctave = 0.3;
periodicityThreshold = 1;
for ii = 1:numberOfLocations
    if abs(log2(f0(max(1,ii-1))/f0(ii)))<maxJumpInOctave
        if abs(log2(f0(min(numberOfLocations,ii+1))/f0(ii)))<maxJumpInOctave
            if sourceObj.periodicityLevel(ii) > periodicityThreshold
                shaper = (0.5+0.5*cos(pi*fx/f0(10)/nCyclesForAP)) ...
                    .*(abs(fx/f0(ii))<nCyclesForAP);
                shapedDeltaSTRAIGHTtmp = real(ifft(fft(shaper) ...
                    .*fft(doubleNormalizedDeltaSTRAIGHT(:,ii))));
                shapedDeltaSTRAIGHT(:,ii) = ...
                    shapedDeltaSTRAIGHTtmp(1:fftl/2+1)/sum(shaper);
            end;
        end;
    end;
end;
fixedAperiodicityMap = ...
    aperiodicityMap.*(1+shapedDeltaSTRAIGHT(1:fftl/fftlAP:end,:));
smoothingWindow = ones(nSmoothing,1);
temporallySmoothedMap = ...
    sqrt(abs(fftfilt(smoothingWindow/sum(smoothingWindow), ... %ones(nSmoothing,1)/nSmoothing,...
    [fixedAperiodicityMap zeros(size(fixedAperiodicityMap,1),biasInsmoothing)]'.^2)))';
temporallySmoothedMap = temporallySmoothedMap(:,biasInsmoothing+1:end);
toc

%%  Return results

revisedSource.temporallySmoothedMap = temporallySmoothedMap;
revisedSource.fixedAperiodicityMap = fixedAperiodicityMap;
revisedSource.dateOfUpdatePeriodicity = datestr(now);

function outputStructure = aperiodicityMap(x,fs,f0,opts)

%%  Initialize internal parameters

targetF0 = 40;
[targetF0Fix,w,shaper] = fitWindowF0set(targetF0,fs);
fftl = 2^ceil(log2(length(w)));

%%  check optional parameters

if isfield(opts,'f0floor')
    f0floor = opts.f0floor;
else
    f0floor = targetF0Fix;
end;
if isfield(opts,'temporalPositions')
    temporalPositions = opts.temporalPositions;
else
    temporalPositions = (0:length(f0)-1)/(length(f0)-1)*length(x)/fs;
end;

outputStructure.FFTsize = fftl;


%% convert original signal intor fixed F0 signal

f0Sequence = f0;
tempF0sequence = f0Sequence;
tempF0sequence(tempF0sequence == 0) = targetF0Fix;
tempF0sequence(tempF0sequence <f0floor) = f0floor;

f0inSamplingRate = interp1(temporalPositions,tempF0sequence, ...
    (0:length(x)-1)/fs,'linear','extrap');
originalPhase = cumsum(2*pi*f0inSamplingRate/fs);
PhaseForConstantF0 = 2*pi*targetF0/fs* ...
    cumsum(ones(ceil(originalPhase(end)/(2*pi*targetF0/fs)),1));
constantF0Signal = interp1(originalPhase,x,PhaseForConstantF0,'linear','extrap');
originalTimeInSamplingRate = interp1(originalPhase,(0:length(originalPhase)-1)/fs, ...
    PhaseForConstantF0,'linear','extrap');
temporalPositionsOnNewTime = interp1(originalTimeInSamplingRate,...
    (0:length(originalTimeInSamplingRate)-1)/fs,temporalPositions,'linear','extrap');

%%  extract aperiodicity parameters

aperiodicity = zeros(length(temporalPositionsOnNewTime),1);
peaksMap = zeros(length(temporalPositionsOnNewTime),round(fs/targetF0Fix*1));
bottomsMap = peaksMap;
tic;
for ii = 1:length(temporalPositionsOnNewTime)
    currentTime = temporalPositionsOnNewTime(ii);
    outputStructure = ...
        aperiodicitySlice(constantF0Signal,fs,targetF0Fix,currentTime,w,shaper);
    aperiodicity(ii) = outputStructure.aperiodicityPower;
    tempPeaks = outputStructure.peaks;
    tempBottms = outputStructure.bottoms;
    bottomsMap(ii,1:length(tempBottms)) = tempBottms';
    peaksMap(ii,1:length(tempPeaks)) = tempPeaks';
end;
toc

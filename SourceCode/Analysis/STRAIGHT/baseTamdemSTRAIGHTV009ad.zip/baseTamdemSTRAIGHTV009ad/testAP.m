%%  Test script for aperiodicity

q2 = aperiodicityRatio(x,rc,2);

%%  convert to aperiodicity information

ap22=displayAperiodicityStructure(q2,0);

%%  Test for single frame
ii = 30;

%figure;plot(hzToERBNnumber(ap22.frequencyAxis),ap22.randomComponent(:,q2.vuv>0));grid on;
fAxis = ap22.frequencyAxis;
aperiodicityPower = ap22.randomComponent(:,ii);
nOfFrames = size(ap22.randomComponent,2);

tic;
targetStrct = fit2SigmoidAperiodicityModel(fAxis,aperiodicityPower,0);
toc

erbAxis = targetStrct.erbCheckPoints(:,ii);
apParameterSequence = zeros(nOfFrames,2);
fittingError = zeros(nOfFrames,1);

for ii = 1:nOfFrames
    aperiodicityPower = ap22.randomComponent(:,ii);
    targetStrct = fit2SigmoidAperiodicityModel(fAxis,aperiodicityPower,0);
    erbAxis = targetStrct.erbCheckPoints;
    apParameter = fminsearch(@(lambda)sigmoidFitFunction(lambda,erbAxis,...
        targetStrct.targetValue),[20 1]);
    apParameterSequence(ii,:) = apParameter;
    fittingError(ii) = sigmoidFitFunction(apParameter,erbAxis,targetStrct.targetValue);
end;
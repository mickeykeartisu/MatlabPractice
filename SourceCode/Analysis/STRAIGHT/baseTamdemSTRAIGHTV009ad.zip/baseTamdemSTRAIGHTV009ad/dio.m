function excitationStruct = dio(x,fs,opt)
% excitationStruct = f0ExtractionByFCE(x,fs,opt);
% excitationStruct = f0ExtractionByFCE(x,fs);
% x : ���͔g�`
% fs : �T���v�����O���g��
% opt : ���͂̃I�v�V����
% opt.f0floor : ���肷��F0�̉������g�� (Hz)
% opt.f0ceil : ���肷��F0�̏�����g�� (Hz)
% opt.framePeriod : F0��framePeriod (ms) ���ɋ��߂�D
% �g�`�f�[�^��50 ms�ȏ�
% �ŏ���30 ms���x�ɗL����������ꍇ�C����ł��܂���D

if length(x)/fs < 0.05
    fprintf('waveform is too short.\n');
end;

f0floor = 40;
f0ceil = 640;
channelsInOctave = 2;
targetSamplingFrequency = 4000;
framePeriod = 5;

defaultConditions.f0floor = f0floor;
defaultConditions.f0ceil = f0ceil;
defaultConditions.framePeriod = framePeriod;
defaultConditions.channelsInOctave = channelsInOctave;
defaultConditions.targetSamplingFrequency = targetSamplingFrequency;

excitationStruct.defaultConditions = defaultConditions;
if nargin == 3
    if isfield(opt, 'f0floor') == 1;
        f0floor = opt.f0floor;
    end;
    if isfield(opt, 'f0ceil') == 1;
        f0ceil = opt.f0ceil;
    end;
    if isfield(opt, 'framePeriod') == 1;
        framePeriod = opt.framePeriod;
    end;
    if isfield(opt, 'channelsInOctave') == 1;
        channelsInOctave = opt.channelsInOctave;
    end;
    if isfield(opt, 'targetSamplingFrequency') == 1;
        targetSamplingFrequency = opt.targetSamplingFrequency;
    end;
elseif nargin < 2
    excitationStruct.rawF0 = [];
    return;
end;

decimationRatio = round(fs/targetSamplingFrequency);
if fs < targetSamplingFrequency
    y = x(:);
    fss = fs;
else
    y = decimate(x(:),decimationRatio,3);
    fss = fs/decimationRatio;
end;
y = y-mean(y);

nBands = ceil(log2(f0ceil/f0floor)*channelsInOctave);
boundaryF0List = f0floor*2.0.^((0:nBands)/channelsInOctave);
boundaryF0List(end) = min(boundaryF0List(end), f0ceil); % �Z�[�t�K�[�h
maxCandidates = length(boundaryF0List); % �t�B���^�����ő���_�ɖ����Ȃ��ꍇ�̍�

lengthInMs = ceil(length(x)/fs*1000);
stabilityMap = zeros(length(boundaryF0List),ceil(lengthInMs));
f0Map = zeros(length(boundaryF0List),ceil(lengthInMs));
fftl = 2^ceil(log(length(y)+ round(fss/boundaryF0List(1) /2)*4 )/log(2));
ySpec = fft(y,fftl);
yLength = length(y);

for ii = 1:length(boundaryF0List)
    r = rawEventByFCE(boundaryF0List(ii), fss, ySpec, yLength, framePeriod/1000, f0floor, f0ceil);
    nLength = min(lengthInMs,length(r.interpolatedF0));
    stabilityMap(ii,1:nLength) = exp(-(r.f0Deviations(1:nLength)./max(0.0000001, r.interpolatedF0(1:nLength) )) ); %�Z�[�t�K�[�h
    f0Map(ii,1:nLength) = r.interpolatedF0(1:nLength);
end;
f0Map = f0Map(:,1:nLength);
stabilityMap = stabilityMap(:,1:nLength);

[nCh, nFrame] = size(f0Map);
[fundamentalNess, sortedIndex] = sort(stabilityMap,1,'descend');
rawF0 = zeros(nFrame, 1);
f0Candidates = zeros(maxCandidates, nFrame);
f0CandidatesScore = zeros(maxCandidates, nFrame);

for ii = 1:nFrame
    rawF0(ii) = f0Map(sortedIndex(1,ii), ii);
    f0Candidates(:,ii) = f0Map(sortedIndex(1:maxCandidates,ii), ii);
    f0CandidatesScore(:,ii) = stabilityMap(sortedIndex(1:maxCandidates,ii), ii);
end;

analysisConditions.f0floor = f0floor;
analysisConditions.f0ceil = f0ceil;
analysisConditions.framePeriod = framePeriod;
analysisConditions.channelsInOctave = channelsInOctave;
analysisConditions.maxCandidates = maxCandidates;
analysisConditions.actualSamplingFrequency = fss;

excitationStruct.analysisConditions = analysisConditions;
excitationStruct.f0 = rawF0;
excitationStruct.f0Candidates =f0Candidates;
excitationStruct.f0CandidatesScore = f0CandidatesScore;
excitationStruct.temporalPositions = r.temporalPositions;
excitationStruct.f0CandidatesMap = f0Map;
excitationStruct.f0CandidatesScoreMap = stabilityMap;

excitationStruct.dateOfAnalysis = datestr(now);
excitationStruct.samplingFrequency = fs;
return

function rawEvent = rawEventByFCE(boundaryF0, fs, xSpec, xLength, shiftTime, f0floor, f0ceil)
nLength = xLength;
halfAverageLength = round(fs/boundaryF0/2);
equivalentFIR = nuttallM(halfAverageLength*4);

[dmy,indexBias] = max(equivalentFIR);

nuttallSpec = fft(equivalentFIR, length(xSpec));

xWOdc2 = real(ifft(nuttallSpec.*xSpec));
xWOdc2 = xWOdc2(indexBias+(1:nLength));

zxNegative = zeroCrossingEngine(xWOdc2,fs);
zxPositive = zeroCrossingEngine(-xWOdc2,fs);
dzxNegative = zeroCrossingEngine(diff(xWOdc2),fs);
dzxPositive = zeroCrossingEngine(-diff(xWOdc2),fs);

usableChannel = max(0,length(zxNegative.eventLocations)-3)* ...
    max(0,length(zxPositive.eventLocations)-3)* ...
    max(0,length(dzxNegative.eventLocations)-3)* ...
    max(0,length(dzxPositive.eventLocations)-3);

timeAxis = 0:shiftTime:(nLength-1)/fs;
if usableChannel>0
    interpolatedF0Set = zeros(4,length(timeAxis));
    interpolatedF0Set(1,:) = max(0,interp1(zxNegative.intervalLocations, ...
        zxNegative.intervalBasedF0s2,timeAxis,'linear','extrap'));
    interpolatedF0Set(2,:) = max(0,interp1(zxPositive.intervalLocations, ...
        zxPositive.intervalBasedF0s2,timeAxis,'linear','extrap'));
    interpolatedF0Set(3,:) = max(0,interp1(dzxNegative.intervalLocations, ...
        dzxNegative.intervalBasedF0s2,timeAxis,'linear','extrap'));
    interpolatedF0Set(4,:) = max(0,interp1(dzxPositive.intervalLocations, ...
        dzxPositive.intervalBasedF0s2,timeAxis,'linear','extrap'));

    rawEvent.interpolatedF0 = mean(interpolatedF0Set);
    rawEvent.f0Deviations = std(interpolatedF0Set);
	% �G���A�̒���
	rawEvent.interpolatedF0(rawEvent.interpolatedF0>boundaryF0) = 0;
	rawEvent.interpolatedF0(rawEvent.interpolatedF0<(boundaryF0/2)) = 0;
	rawEvent.interpolatedF0(rawEvent.interpolatedF0>f0ceil) = 0;
	rawEvent.interpolatedF0(rawEvent.interpolatedF0<f0floor) = 0;
	
    rawEvent.f0Deviations(rawEvent.interpolatedF0==0) = 100000; % �K���ȃZ�[�t�K�[�h
    rawEvent.negativeEdgeF0 = interpolatedF0Set(1,:);
else
    rawEvent.interpolatedF0 = timeAxis*0+1;
    rawEvent.f0Deviations = timeAxis*0+1;
    rawEvent.negativeEdgeF0 = timeAxis*0+1;
end;
rawEvent.temporalPositions = timeAxis;

function eventStrct = zeroCrossingEngine(x,fs)
negativeGoindPoints2 = ...
    (1:length(x))'.*(([x(2:end);x(end)].*x<0).*([x(2:end);x(end)]<x));

edges2 = negativeGoindPoints2(negativeGoindPoints2>0);

fineEdges2 = edges2-x(edges2)./(x(edges2+1)-x(edges2));
eventStrct.intervalBasedF0s2 = fs./diff(fineEdges2);
eventStrct.intervalLocations = (fineEdges2(1:end-1)+fineEdges2(2:end))/2/fs;
eventStrct.eventLocations = fineEdges2/fs;
eventStrength = abs(x(edges2+1)-x(edges2))/std(x);
eventStrct.intervalStrength = (eventStrength(1:end-1)+eventStrength(2:end))/2;
eventStrct.eventStrength = eventStrength;

function w = nuttallM(n)
tt = ((1:n)'-(n+1)/2)/(n+1);
w = 0.355768+0.487396*cos(2*pi*tt)+0.144232*cos(4*pi*tt)+0.012604*cos(6*pi*tt);

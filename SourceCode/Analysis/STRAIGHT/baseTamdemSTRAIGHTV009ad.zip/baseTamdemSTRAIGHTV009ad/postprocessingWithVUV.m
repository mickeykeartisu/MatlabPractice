function [f0, vuv] = postprocessingWithVUV(r)

%allowedRange = 0.1; % 20 %�̑J�ڂ����e����
allowedRange = 0.1; % 20 %�̑J�ڂ����e����
voiceRangeMinimum = round(1/(r.temporalPositions(2) - r.temporalPositions(1))/r.analysisConditions.f0floor); % f0floor�͂Ƃ肠�����Œ�

timeAxis = r.temporalPositions;
f0 = timeAxis*0;

% �܂��́C�x�X�g�̉���p�ӂ���
f0Base = r.f0;
f0Base(1:voiceRangeMinimum) = 0;
f0Base(end-voiceRangeMinimum+1:end) = 0;
f0Step1 = f0;

% ������x�A�����Ă���ꍇ�͏C���������Ƃ���D
for ii = voiceRangeMinimum:length(f0)
    if (abs((f0Base(ii)-f0Base(ii-1))/(0.000001+f0Base(ii)) )) < allowedRange
        f0Step1(ii) = f0Base(ii);
    end
end;

% ������Ԃ̐؂藣��
f0Step2 = f0Step1;
for ii = voiceRangeMinimum:length(f0)
    for jj = 1:voiceRangeMinimum
        if f0Step1(ii+1-jj) == 0
            f0Step2(ii) = 0;
            break;
        end;
    end;
end;

% �����̌��o
positiveIndex = f0Step2*0;
negativeIndex = f0Step2*0;
negativeCount = 0;
positiveCount = 0;
for ii = 2:length(positiveIndex)
    if f0Step2(ii) == 0 && f0Step2(ii-1) ~= 0
        negativeCount = negativeCount + 1;
        negativeIndex(negativeCount) = ii-1;
    elseif f0Step2(ii-1) == 0 && f0Step2(ii) ~= 0
        positiveCount = positiveCount + 1;
        positiveIndex(positiveCount) = ii;
    end;
end;

% �O�����␳
f0Step3 = f0Step2;
candidates = 9;
for ii = 1:negativeCount
    for jj = negativeIndex(ii):length(f0Step3)-1
        refValue = f0Step3(jj)*2 - f0Step3(jj-1);
        bestError = abs(refValue - r.f0CandidatesMap(1, jj+1));
        for kk = 2:candidates
            errorValue = abs(refValue - r.f0CandidatesMap(kk, jj+1));
            if errorValue < bestError
                bestError = errorValue;
                f0Step3(jj+1) = r.f0CandidatesMap(kk, jj+1);
            end;
        end;
        if bestError / (refValue+0.0001) > allowedRange % F0�͒Z���ԂŒ��􂵂Ȃ�
            negativeIndex(ii) = jj; %%%%
            f0Step3(jj+1) = 0;
            break;
        end;
        if ii ~= negativeCount && jj == positiveIndex(ii+1)-1 % ���̋�Ԃɍ����|��������~�߂�
            negativeIndex(jj) = jj;
            break;
        end;
    end;
end;

% ������␳
f0Step4 = f0Step3;
for ii = positiveCount:-1:1
    for jj = positiveIndex(ii):-1:2
        refValue = f0Step4(jj)*2 - f0Step4(jj+1);
        bestError = abs(refValue - r.f0CandidatesMap(1, jj-1));
        for kk = 2:candidates
            errorValue = abs(refValue - r.f0CandidatesMap(kk, jj-1));
            if errorValue < bestError
                bestError = errorValue;
                f0Step4(jj-1) = r.f0CandidatesMap(kk, jj-1);
            end;
        end;
        if bestError / (refValue+0.0001) > allowedRange% F0�͒Z���ԂŒ��􂵂Ȃ�
            f0Step4(jj-1) = 0;
            positiveIndex(ii) = jj; %%%%
            break;
        end;
        if ii ~= 1 && jj == negativeIndex(ii-1)+1 % ���̋�Ԃɍ����|��������~�߂�
            break;
        end;
    end;
end;

f0 = f0Step4;
vuv = zeros(length(f0), 1);
for ii = 1:length(f0)
    if f0(ii) ~= 0
        vuv(ii) = 1;
    end;
end;

% STRAIGHT�g�ݍ��ݗp�̃A�h�z�b�N�ȏ���(�����I�ɂ͏C�����܂�)
% �ŏ��̏C��
for ii = 1:length(f0)
    if f0Step4(ii) ~= 0
        begin = ii;
        break;
    end;
end;
for ii = begin-1:-1:1
    f0Step4(ii) = f0Step4(begin);
end;
% �Ō�̏C��
for ii = length(f0):-1:1
    if f0Step4(ii) ~= 0
        finish = ii;
        break;
    end;
end;
for ii = finish+1:length(f0)
    f0Step4(ii) = f0Step4(finish);
end;

% �O�����␳
f0Step5 = f0Step4;
for ii = 1:negativeCount-1
    for jj = negativeIndex(ii):positiveIndex(ii+1)-1
        f0Step5(jj) = f0Step5(negativeIndex(ii)) + (f0Step5(positiveIndex(ii+1))-f0Step5(negativeIndex(ii)))...
            * (jj-negativeIndex(ii))/(positiveIndex(ii+1)-negativeIndex(ii));
    end;
end;
f0 = f0Step5;
return;


%%  quick check for spectral estimation

directoryBase = '/Users/kawahara/m-file/ANNYSTRAIGHT/baseTamdemSTRAIGHTV009ac/';
%directoryBase = '/Users/kawahara/m-file/ANNYSTRAIGHT/testData/';
%directoryBase = '/Users/kawahara/Music/F0_DB/Atake_DB/EGG_VOL1/WAV/M02/';
%directoryBase = '/Users/kawahara/Music/F0_DB/Atake_DB/EGG_VOL1/WAV/M02/';
%directoryBase = '/Users/kawahara/m-file/ANNYSTRAIGHT/tuningTests/';
fileName = 'vaiueo2d.wav';
%fileName = 'openTheCrate.wav';
%fileName = 'sc005org.wav';
%fileName = 'M02-JA01F054-2.WAV';
%fileName = 'M02-JA01F054-2.WAV';
%fileName = 'bakuon2.wav';
%fileName = 'randomPeriodicSignal.wav';

%%

[x,fs] = wavread([directoryBase fileName]);

x = x(:,1);
soundsc(x,fs)
r = exF0candidatesTSTRAIGHTGB(x,fs)
x = removeLF(x,fs,r.f0,r.periodicityLevel);
r = exF0candidatesTSTRAIGHTGB(x,fs)
rc = r;
%%rc = vuvDetector(r);
rc = autoF0Tracking(r,x);
rc.vuv = refineVoicingDecision(x,rc);
%rc.vuv = rc.vuv*0;

figure;
plot(rc.temporalPositions,rc.f0);grid on
set(gca,'fontsize',14);
xlabel('time (s)')
ylabel('fundamental frequency (Hz)');
title('fundamental frequency')

%q = aperiodicityRatio(x,rc,1)
%q = aperiodicityRatioSigmoid(x,rc,1)
q = aperiodicityRatioSigmoid(x,rc,1,2,0);

%displayAperiodicityStructure(q,1);

f = exSpectrumTSTRAIGHTGB(x,fs,q)
STRAIGHTobject.waveform = x;
STRAIGHTobject.samplingFrequency = fs;
STRAIGHTobject.refinedF0Structure.temporalPositions = r.temporalPositions;
STRAIGHTobject.SpectrumStructure.spectrogramSTRAIGHT = f.spectrogramSTRAIGHT;
STRAIGHTobject.refinedF0Structure.vuv = rc.vuv;
f.spectrogramSTRAIGHT = unvoicedProcessing(STRAIGHTobject);

sgramSTRAIGHT = 10*log10(f.spectrogramSTRAIGHT);
maxLevel = max(max(sgramSTRAIGHT));
figure;
imagesc([0 f.temporalPositions(end)],[0 fs/2],max(maxLevel-80,sgramSTRAIGHT));
axis('xy')
set(gca,'fontsize',14);
xlabel('time (s)')
ylabel('frequency (Hz)');
title('STRAIGHT spectrogram')

s = exTandemSTRAIGHTsynthNx(q,f)
soundsc(s.synthesisOut,fs)

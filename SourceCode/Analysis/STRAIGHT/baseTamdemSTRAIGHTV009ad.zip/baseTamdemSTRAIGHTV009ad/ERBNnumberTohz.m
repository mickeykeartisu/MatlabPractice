function f = ERBNnumberTohz(erbnNumber)
f = (10.^(erbnNumber/21.4)-1)/0.00437;
return;
function gdbAttributes = groupDelayBasedAttributes(signal,fftl,fs,cornerFrequencies)
% gdbAttributes = groupDelayBasedAttributes(signal,fftl,fs,cornerFrequencies)
% Input arguments
% signal : input signal.
% fftl : FFT length (samples)
% fs : sampling frequency (Hz)
% cornerFrequencies : list of boundary frequencies (Hz)
% output arguments
%   gdbAttributes : a structure for return values

%   August 2, 2006 originally programmed by Masanori Morise
%   August 5, 2006 revised and reconstructed by Hideki Kawahara
%   August 7, 2006 generalized by Hideki Kawahara

gdbAttributes = [];
if nargin ~= 4
   fprintf('gdbAttributes = groupDelayBasedAttributes(x,fftl,fs,cornerFrequencies)\n');
   return;
end;
if isempty(fftl) || (fftl<length(signal))
    fftl = 2^ceil(log(length(signal))/log(2));
end;
if max(cornerFrequencies)>=fs/2 || min(cornerFrequencies)<=0
    fprintf('cornerFrequencies are out of range.\n');
    return;
end;

%level normalization
%s = sum(signal(:)'.^2) ;%/ fs;
x = signal(:)';% / sqrt(s);

%group delay calculation
sw=fft(x,fftl);
sw=sw+max(abs(sw))/1000000000; % safe guard
tt = (1:length(x)) / fs;
swt=fft(-x.*tt*i,fftl);
gdw = -imag(-swt./sw);
gdw = gdw-1/fs;
%average time calculation
tabb = sum(gdw.*(abs(sw).^2))/sum(abs(sw).^2);

%calculation of duration
%%% first term (effect of spectral dynamics)
du1 = ((real(sw).*real(swt) + imag(sw).*imag(swt))./abs(sw)) .^2;
%%% second term (group delay dispersion)
du2 = ((gdw - tabb).^2) .* (abs(sw)).^2;

dur = sum(du1+du2)/sum((abs(sw)).^2);
% calculation of duration and bandwise average time
fftl2 = fftl/2+1;
du1(fftl2) = du1(fftl2)/2;
du2(fftl2) = du2(fftl2)/2;
gdw(fftl2) = gdw(fftl2)/2;
cumDur = cumsum([0 (du1(1)+du2(1))/2 du1(2:end)+du2(2:end)]);%/ fftl / fs;
cumPower = cumsum([0 ((abs(sw(1))).^2)/2 (abs(sw(2:end))).^2]);%/sum((abs(sw)).^2);
cumTime = cumsum([0 gdw(1).*(abs(sw(1)).^2)/2 gdw(2:end).*(abs(sw(2:end)).^2)]);
freqAxis = [0 0.00001+(0:fftl-1)/fftl*fs];
boundaryValues = interp1(freqAxis,cumDur,[0 cornerFrequencies fs/2]);
boundaryPowers = interp1(freqAxis,cumPower,[0 cornerFrequencies fs/2]);
bandWiseDuration = diff(boundaryValues)./diff(boundaryPowers);
boundaryTimes = interp1(freqAxis,cumTime,[0 cornerFrequencies fs/2]);
bandWiseAverageTime = diff(boundaryTimes)./diff(boundaryPowers);
%du = (boundaryValues(2)-boundaryValues(1))/(boundaryPowers(2)-boundaryPowers(1));
%du = (sum(du1(range)) + sum(du2(range))) / fftl / fs;

% output results
gdbAttributes.fftl = fftl;
gdbAttributes.fs = fs;
gdbAttributes.averageTime = -tabb;
gdbAttributes.duration = sqrt(dur);
gdbAttributes.bandWiseAverageTime = -bandWiseAverageTime;
gdbAttributes.bandWiseDuration = sqrt(bandWiseDuration);
gdbAttributes.boundaryFrequencies = [0 cornerFrequencies fs/2];


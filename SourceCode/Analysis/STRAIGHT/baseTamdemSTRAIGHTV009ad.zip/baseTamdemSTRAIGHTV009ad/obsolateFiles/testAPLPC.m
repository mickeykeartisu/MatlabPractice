%%  LPC-based aperiodicity extraction
%   Designed and coded by Hideki Kawahara
%   02/Oct./2008
%   16/Oct./2008
%   17/Oct./2008

dataDirectory = '../../ANNYSTRAIGHT/testData/';
inputName = 'vaiueo2d.wav';
[x,fs] = wavread([dataDirectory inputName]);

%%  extract F0 at first

r = exF0candidatesTSTRAIGHTGB(x,fs);

%%  check for each frame

nFrames = size(r.temporalPositions,2);
nDataLength = size(x,1);
figure;
topLevel = max(x);
bottomLevel = min(x);
for ii = 1:nFrames
    currentF0 = r.f0(ii);
    currentPositionInSample = round(r.temporalPositions(ii)*fs)+1;
    segmentLength = round(fs/currentF0/2)*2+1; % make it odd number
    indexBias = round(fs/currentF0/2);
    segmentIndex = max(1,min(nDataLength,currentPositionInSample-indexBias ...
        +(1:segmentLength)'));
    if 1 == 2
        plot((1:segmentLength),x(segmentIndex));
        axis([1 segmentLength bottomLevel topLevel]);
        drawnow;
    end;
end;

%%  make pre and post segment with some margin

nFrames = size(r.temporalPositions,2);
nDataLength = size(x,1);
marginList = [1 2 3 4 5 6 7 8];
rmsResidual = zeros(nFrames,length(marginList));
elapsedTimeList = zeros(length(marginList),1);
for kk = 1:length(marginList)
    nMarginBias = marginList(kk);
    nMargin = nMarginBias*2+1; % this also shoudl be a odd number

    %figure;
    topLevel = max(x);
    bottomLevel = min(x);
    tic;
    for ii = 1:nFrames
        currentF0 = r.f0(ii);
        t0InSamples = round(fs/currentF0);
        currentPositionInSample = round(r.temporalPositions(ii)*fs)+1;
        segmentLength = round(fs/currentF0/2)*2+1; % make it odd number
        indexBias = round(fs/currentF0/2);
        segmentIndex = max(1,min(nDataLength,currentPositionInSample-indexBias ...
            +(1:segmentLength)'));
        H = zeros(segmentLength,nMargin*2);
        for jj = -nMarginBias:nMarginBias
            preSegmendIndex = max(1,min(nDataLength,jj+ ...
                currentPositionInSample-indexBias-t0InSamples+(1:segmentLength)'));
            H(:,jj+nMarginBias+1) = x(preSegmendIndex);
            postSegmendIndex = max(1,min(nDataLength,jj+ ...
                currentPositionInSample-indexBias+t0InSamples+(1:segmentLength)'));
            H(:,jj+nMarginBias+1+nMargin) = x(postSegmendIndex);
        end;
        a = inv(H'*H)*(H'*x(segmentIndex));
        rmsResidual(ii,kk) = std(x(segmentIndex)-H*a)/std(x(segmentIndex));
        if 1 == 2
            plot((1:segmentLength),x(segmentIndex));
            axis([1 segmentLength bottomLevel topLevel]);
            drawnow;
        end;
    end;
    elapsedTimeList(kk) = toc;
    %residualObj = f0PredictionResidual(x,fs,r,nMarginBias);
end;
figure;plot(r.temporalPositions,rmsResidual');grid on;
xlabel('time (s)')
ylabel('normalized residuals');
figure;plot(marginList*2+1,elapsedTimeList);grid on;
xlabel('total number of clue')
ylabel('elapsed time (s)');

%%  Test with QMF

fName = '../testData/vaiueo2d.wav';
%fName = '../testData/kousyouAD24.wav';
%fName = '../testData/bakuon3.wav';

nominalCutOff = 2000;

load setQMFv1;

cutOffList = (fs/4);
while cutOffList(end) > nominalCutOff
    cutOffList = [cutOffList; cutOffList(end)/2];
end;

speedOfSound = 340; % m/s
vocalTractLength = 0.17; % m
wholeSignal = randn(length(x),1);
timeConstant = 0.001;
frameShift = 0.001;
nMarginBias = 3;
residualMatrix = zeros(length(cutOffList)+1,nFrames);

for ii = 1:length(cutOffList)
    fsTmp = cutOffList(ii)*2;
    nSections = round((vocalTractLength/speedOfSound)*fs*2+2);
    highSignal = fftfilt(hHP,wholeSignal);
    lowSignal = fftfilt(hLP,wholeSignal);
    temporalBiasHigh = length(hHP)/2/(fsTmp*2);
    temporalBiasLow = length(hLP)/2/(fsTmp*2);
    soundsc(highSignal(1:2:end),fsTmp);
    downSampledHighSignal = highSignal(1:2:end);
    residualObj = f0PredictionResidual(downSampledHighSignal,fsTmp,r,nMarginBias,-length(hHP)/2/fsTmp);
    wholeSignal = lowSignal(1:2:end);
    residualMatrix(length(cutOffList)+1-ii+1,:) = residualObj.rmsResidual';
end;
residualObjW = f0PredictionResidual(wholeSignal,fsTmp,r,nMarginBias,-length(hLP)/2/fsTmp);
residualMatrix(1,:) = residualObjW.rmsResidual';

%%  show cumulative distribution

sortedResidual = sort(min(1,residualMatrix'));
figure;
plot(sortedResidual,(1:size(sortedResidual,1))/size(sortedResidual,1)*100);
grid on;

%%  Test with QMF and fixed evaluation length

fName = '../testData/vaiueo2d.wav';
%fName = '../testData/kousyouAD24.wav';
%fName = '../testData/bakuon3.wav';

nominalCutOff = 2000;

load setQMFv1;

cutOffList = (fs/4);
while cutOffList(end) > nominalCutOff
    cutOffList = [cutOffList; cutOffList(end)/2];
end;

speedOfSound = 340; % m/s
vocalTractLength = 0.17; % m
wholeSignal = randn(length(x),1);
timeConstant = 0.001;
frameShift = 0.001;
nMarginBias = 6;
residualMatrix = zeros(length(cutOffList)+1,nFrames);
windowLengthMs = 20;

for ii = 1:length(cutOffList)
    fsTmp = cutOffList(ii)*2;
    nSections = round((vocalTractLength/speedOfSound)*fs*2+2);
    highSignal = fftfilt(hHP,wholeSignal);
    lowSignal = fftfilt(hLP,wholeSignal);
    temporalBiasHigh = length(hHP)/2/(fsTmp*2);
    temporalBiasLow = length(hLP)/2/(fsTmp*2);
    soundsc(highSignal(1:2:end),fsTmp);
    downSampledHighSignal = highSignal(1:2:end);
    residualObj = f0PredictionResidualFixSegment(downSampledHighSignal,...
        fsTmp,r,nMarginBias,-length(hHP)/2/fsTmp,windowLengthMs);
    wholeSignal = lowSignal(1:2:end);
    residualMatrix(length(cutOffList)+1-ii+1,:) = residualObj.rmsResidual';
end;
soundsc(wholeSignal,fsTmp);
residualObjW = f0PredictionResidualFixSegment(wholeSignal,...
    fsTmp,r,nMarginBias,-length(hLP)/2/fsTmp,windowLengthMs);
residualMatrix(1,:) = residualObjW.rmsResidual';
%%  clean up f0data

rTrim = r;
rTrim.f0(1:24) = rTrim.f0(1:24)*0;
rTrim.f0(144:end) = rTrim.f0(144:end)*0;
rStretch = rTrim;
targetF0 = min(rTrim.f0(rTrim.f0>0));
f0Edit = rTrim.f0;
f0Edit(rTrim.f0 == 0) = rTrim.f0(rTrim.f0 == 0)+targetF0;
rStretch.f0(rStretch.f0 == 0) = rStretch.f0(rStretch.f0 == 0)+targetF0;
originalSignalTime = (0:length(x)-1)/fs;
interpolatedF0 = interp1(rStretch.temporalPositions,rStretch.f0, ...
    originalSignalTime,'linear','extrap');
stretchedTime = cumsum(interpolatedF0/targetF0/fs);
stretchedSignal = interp1(stretchedTime,x,0:1/fs:stretchedTime(end),'linear','extrap');
rStretch.temporalPositions = ...
    interp1(originalSignalTime,stretchedTime,r.temporalPositions,'linear','extrap');

%%  Test with QMF and fixed evaluation length and Hanning weighting

windowLengthMs = 30;windowLength = windowLengthMs/1000;

testType = 'simulation';
testType = 'speech';
testType = 'timeNormalize';
lowLimit = 0;
switch testType
    case 'simulation'
        dataLength = 2;
        samplingFrequency = 44100;
        framePeriod = 0.010;
        sourceStr.temporalPositions = (0:framePeriod:dataLength);
        sourceStr.f0 = (sourceStr.temporalPositions*0+100)';
        signalTime = (0:1/samplingFrequency:dataLength)';
        wholeSignal = randn(length(signalTime),1);
        additionalMask = sourceStr.temporalPositions*0+1;
    case 'speech'
        sourceStr = rTrim;
        samplingFrequency = fs;
        wholeSignal = x;
        additionalMask = sourceStr.temporalPositions*0+1;
    case 'timeNormalize'
        windowLengthMs = 2000/targetF0;
        windowLength = windowLengthMs/1000;
        rStretch.f0 = rStretch.f0*0+targetF0;
        sourceStr = rStretch;
        samplingFrequency = fs;
        wholeSignal = stretchedSignal(:);
        additionalMask = rTrim.f0'>0;
        stretchingFactor = f0Edit/targetF0;
end;
nominalCutOff = 1000;
nFrames = size(sourceStr.f0,1);

load setQMFv1;

cutOffList = (samplingFrequency/4);
while cutOffList(end) > nominalCutOff
    cutOffList = [cutOffList; cutOffList(end)/2];
end;

nMarginBias = 2;
residualMatrix = zeros(length(cutOffList)+1,nFrames);

for ii = 1:length(cutOffList)
    fsTmp = cutOffList(ii)*2;
    highSignal = fftfilt(hHP,wholeSignal);
    lowSignal = fftfilt(hLP,wholeSignal);
    temporalBiasHigh = length(hHP)/2/(fsTmp*2);
    temporalBiasLow = length(hLP)/2/(fsTmp*2);
    soundsc(highSignal(1:2:end),fsTmp);
    downSampledHighSignal = highSignal(1:2:end);
    residualObj = f0PredictionResidualFixSegmentW(downSampledHighSignal,...
        fsTmp,sourceStr,nMarginBias,-length(hHP)/2/fsTmp,windowLengthMs);
    wholeSignal = lowSignal(1:2:end);
    residualMatrix(length(cutOffList)+1-ii+1,:) = residualObj.rmsResidual';
end;
soundsc(wholeSignal,fsTmp);
residualObjW = f0PredictionResidualFixSegmentW(wholeSignal,...
    fsTmp,sourceStr,nMarginBias,-length(hLP)/2/fsTmp,windowLengthMs);
residualMatrix(1,:) = residualObjW.rmsResidual';

indexMask = (sourceStr.temporalPositions>windowLength) & ...
    (sourceStr.temporalPositions<sourceStr.temporalPositions(end)-windowLength) ...
    & (sourceStr.f0'>lowLimit)& additionalMask;
cleanedResidual = residualMatrix(:,indexMask);

sortedResidual = sort(min(1,cleanedResidual'));
figure;
plot(sortedResidual,(1:size(sortedResidual,1))/size(sortedResidual,1)*100);
grid on;
axis([0 1 0 100]);

%%


rTrim = r;
rTrim.f0(1:24) = rTrim.f0(1:24)*0;
rTrim.f0(144:end) = rTrim.f0(144:end)*0;
rStretch = rTrim;
targetF0 = min(rTrim.f0(rTrim.f0>0));
f0Edit = rTrim.f0;
f0Edit(rTrim.f0 == 0) = rTrim.f0(rTrim.f0 == 0)+targetF0;
rStretch.f0(rStretch.f0 == 0) = rStretch.f0(rStretch.f0 == 0)+targetF0;
gg = reshape([x,zeros(length(x),3)]',length(x)*4,1);
ggs = conv(hanning(7),gg);
originalSignalTime = (0:length(ggs)-1)/(fs*4);
interpolatedF0 = interp1(rStretch.temporalPositions,rStretch.f0, ...
    originalSignalTime,'linear','extrap');
stretchedTime = cumsum(interpolatedF0/targetF0/(fs*4));
stretchedSignal4 = interp1(stretchedTime,ggs,0:1/(fs*4):stretchedTime(end),'linear','extrap');
rStretch.temporalPositions = ...
    interp1(originalSignalTime,stretchedTime,r.temporalPositions,'linear','extrap');
stretchedSignal = decimate(stretchedSignal4,4);


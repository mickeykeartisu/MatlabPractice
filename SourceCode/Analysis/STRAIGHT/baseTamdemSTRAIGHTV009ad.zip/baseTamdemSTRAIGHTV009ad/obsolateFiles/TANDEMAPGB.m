function [ap,statusParams] = TANDEMAPGB(x,fs,f0,tc,cyclesTotal)
%   Aperiodicity estimation using TANDEM technique
%   [ap,statusParams] = TANDEMAPGB(x,fs,f0,tc)
%   This is a reduced version operating only on constant F0
%   Inputs
%       x   : input signal
%       fs  : sampling frequency (Hz)
%       f0  : fundamental frequency (Hz)
%       tc  : current position (second)
%       cyclesTotal  : span of spatial frequency filter in number of cycles

%   Designed and Coded by Hideki Kawahara
%   24/Oct./2007 
%   16/Dec./2007 renamed

%   set known initial parameters
optionalParams.correctionForBlackman = 2;
fl = f0/2;
cycles = cyclesTotal/2;

tSTRAIGHTresults = ...
    TandemSTRAIGHTGeneralBody(x,fs,f0,tc,fl,optionalParams);
sliceSTRAIGHT = tSTRAIGHTresults.sliceSTRAIGHT;
sliceTANDEM = tSTRAIGHTresults.sliceTANDEM;
fftl = (length(sliceSTRAIGHT)-1)*2;
normalizedSpectrum = (sliceTANDEM./sliceSTRAIGHT)-1;
periodLength = (f0/fs*fftl);
baseAxis = 0:periodLength*cycles;
baseAxis = [-baseAxis(end:-1:2) baseAxis]';
quadratureSignal = (0.5+0.5*cos(pi*baseAxis/periodLength/cycles)).* ...
    exp(-i*2*pi*baseAxis/periodLength);
%ap = 1;
statusParams.quadratureSignal = quadratureSignal;
statusParams.normalizedSpectrum = normalizedSpectrum;
statusParams.sliceSTRAIGHT = sliceSTRAIGHT;
statusParams.tSTRAIGHTanalysisConditions = tSTRAIGHTresults.analysisConditions;
ap = fftfilt(quadratureSignal,...
    [normalizedSpectrum(end:-1:2);normalizedSpectrum;...
    normalizedSpectrum(end-1:-1:2)]);
ap = abs(ap(length(normalizedSpectrum)+(length(baseAxis)-1)/2 ...
    +(1:fftl/2+1))/sum(abs(quadratureSignal)));
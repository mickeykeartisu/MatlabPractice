function updatedSourceStr = vuvDetector(sourceStr)

updatedSourceStr = sourceStr;
periodicityLevel = sourceStr.periodicityLevel;
nFrames = length(periodicityLevel);
f0 = sourceStr.f0;
thershold = 1.4;

averagedF0 = mean(f0(periodicityLevel>1.6));
aperture = 1/averagedF0;

temporalPositions = sourceStr.temporalPositions;
frontPeriodicity = interp1(temporalPositions,periodicityLevel, ...
    temporalPositions+aperture);
backPeriodicity = interp1(temporalPositions,periodicityLevel, ...
    temporalPositions-aperture);
modifiedPeriodicity = max([periodicityLevel,frontPeriodicity(:),...
    backPeriodicity(:)]');
updatedSourceStr.f0(modifiedPeriodicity<thershold) = ...
    updatedSourceStr.f0(modifiedPeriodicity<thershold)*0;
updatedSourceStr.periodicityLevel = modifiedPeriodicity;
function residualObj = f0PredictionResidualFixSegment(x,fs,r,nMarginBias,initialTime,durationMs)
%   residualObj =
%   f0PredictionResidualFixSegment(x,fs,r,nMarginBias,initialTime,durationMs)
%   Prediction error with
%       Fixed evaluation segment length
%       Rectangular weighting

%   Designed and coded by Hideki Kawahara
%   03/Oct./2008
%   16/Oct./2008

nMargin = nMarginBias*2+1; % this also shoudl be a odd number
nFrames = length(r.temporalPositions);
rmsResidual = zeros(nFrames,1);
nDataLength = length(x);
topLevel = max(x);
bottomLevel = min(x);
segmentLength = round(fs*durationMs/1000/2)*2+1;
%tic;
for ii = 1:nFrames
    currentF0 = r.f0(ii);
    t0InSamples = round(fs/currentF0);
    currentPositionInSample = round(-initialTime+r.temporalPositions(ii)*fs)+1;
%    segmentLength = round(fs/currentF0/2)*2+1; % make it odd number
    indexBias = round(fs/currentF0/2);
    segmentIndex = max(1,min(nDataLength,currentPositionInSample-indexBias ...
        +(1:segmentLength)'));
    H = zeros(segmentLength,nMargin*2);
    for jj = -nMarginBias:nMarginBias
        preSegmendIndex = max(1,min(nDataLength,jj+ ...
            currentPositionInSample-indexBias-t0InSamples+(1:segmentLength)'));
        H(:,jj+nMarginBias+1) = x(preSegmendIndex);
        postSegmendIndex = max(1,min(nDataLength,jj+ ...
            currentPositionInSample-indexBias+t0InSamples+(1:segmentLength)'));
        H(:,jj+nMarginBias+1+nMargin) = x(postSegmendIndex);
    end;
    a = inv(H'*H)*(H'*x(segmentIndex));
    rmsResidual(ii) = std(x(segmentIndex)-H*a)/std(x(segmentIndex));
    if 1 == 2
        plot((1:segmentLength),x(segmentIndex));
        axis([1 segmentLength bottomLevel topLevel]);
        drawnow;
    end;
end;
%elapsedTimeList(kk) = toc;
residualObj.rmsResidual = rmsResidual;
residualObj.samplingFrequency = fs;


function erbnNumber = hzToERBNnumber(f)

erbnNumber = 21.4*log10(0.00437*f+1);
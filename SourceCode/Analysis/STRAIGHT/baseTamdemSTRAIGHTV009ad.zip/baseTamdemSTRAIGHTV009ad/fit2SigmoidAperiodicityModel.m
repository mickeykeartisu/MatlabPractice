function sigmoidStructure = fit2SigmoidAperiodicityModel(fAxis,aperiodicityPower,displayOn)

erbnNumberAxis = hzToERBNnumber(fAxis);
erbCheckPoints = [10:0.5:floor(max(erbnNumberAxis))];

targetValue = interp1(erbnNumberAxis,aperiodicityPower,erbCheckPoints,'linear','extrap');
if displayOn
    figure;plot(erbCheckPoints,targetValue);grid on;
    axis([0 erbCheckPoints(end) 0 1]);
end;
sigmoidStructure.erbCheckPoints = erbCheckPoints;
sigmoidStructure.targetValue = targetValue;
return;
function err = sigmoidFitFunction(lambda,x,y)

ySigmoid = max(0.00001,0.9./(1+exp(-(x(:)-lambda(1))/lambda(2))) ...
    -0.9./(1+exp(-(13-lambda(1))/lambda(2))));
err = sum(abs(y(:)-ySigmoid).^2)/length(x);


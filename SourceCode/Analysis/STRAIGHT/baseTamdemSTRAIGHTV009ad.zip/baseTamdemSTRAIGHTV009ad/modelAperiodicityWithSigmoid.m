function apStructure = modelAperiodicityWithSigmoid(apStructure,displayOn,aperiodicityExponent)

if nargin == 1
    displayOn = 0;
    aperiodicityExponent = 1/3;
elseif nargin == 2
    aperiodicityExponent = 1/3;
end;

f0 = apStructure.f0;
fs = apStructure.samplingFrequency;
targetF0 = apStructure.targetF0;
locations = apStructure.temporalPositions;
nFrames = length(locations);
cutOffListFix = apStructure.cutOffListFix;
fixBandCenter = [cutOffListFix(1)/sqrt(2);cutOffListFix*sqrt(2)];
baseBandAperiodicComponent = abs(1-apStructure.periodicityLevel);
residualMatrixFix = apStructure.residualMatrixFix;
if displayOn
    figure;
    fftl = 1024;
    fx = (0:fftl/2)/fftl*fs;
    fxInERB = hzToERBNnumber(fx);
end;
for ii = 1:nFrames
    actualFixCenter = fixBandCenter/targetF0*f0(ii);
    actualFixCenterRev = [f0(ii);sqrt(f0(ii)*actualFixCenter(1));actualFixCenter];
    actualLevelRev = [[1;1;1]*min(baseBandAperiodicComponent(ii),residualMatrixFix(1,ii));residualMatrixFix(2:end,ii)];
    sigmoidStructure = ...
        fitSigmoidToRandomLevel(actualFixCenterRev(actualFixCenterRev<fs/2),...
        actualLevelRev(actualFixCenterRev<fs/2),actualFixCenter(1),fs,aperiodicityExponent);
    centerInERBN = hzToERBNnumber(sigmoidStructure.centerFrequency);
    edgeInERBN = hzToERBNnumber(sigmoidStructure.edgeFrequency);
    baseLevel = sigmoidStructure.baseLevel;
    apStructure.sigmoidStructure(ii) = sigmoidStructure;
    if displayOn
        semilogx(actualFixCenterRev(actualFixCenterRev<fs/2),actualLevelRev(actualFixCenterRev<fs/2),'o-');
        title(['Frame:' num2str(ii) '  at:' num2str(locations(ii)) ' (s)']);
        y = sigmoidModelForAperiodicComponent(fxInERB,baseLevel,edgeInERBN,centerInERBN);
        hold on;
        semilogx(fx,y.^(1/aperiodicityExponent),'r');
        hold off;
        axis([100 fs 0 1.1]);grid on;
        drawnow;
        pause(0.2);
    end;
end;
return;
function okInd = loadSubstrateMatFile

[FileName,PathName] = uigetfile('*.mat','Select the substrate mat file')
if length(FileName) == 1 && length(PathName) == 1
    if FileName == 0 || PathName == 0
        disp('Load is cancelled!');
        return;
    end;
end;
eval(['load ' PathName FileName]);
if exist('revisedData') ~= 1
    disp([PathName FileName 'is not morphing substrate.']);
    okInd = 0;
    return;
end;
yesno = menu('OK to reflesh with the read data?','Yes. refrech','No. cancel')
switch yesno
    case 1
        close('templateGUIforTSmorping');
        templateGUIforTSmorping(revisedData)
        okInd = 1;
    otherwise
        disp('Loading substrate is cancelled.')
        okInd = 0;
        return;
end;
return;
function okInd = loadAnchorInTextFile(mSubstrate)

okInd = [];
[FileName,PathName] = uigetfile('*.txt','Select the anchor text file.')
if length(FileName) == 1 && length(PathName) == 1
    if FileName == 0 || PathName == 0
        disp('Load is cancelled!');
        return;
    end;
end;
fid = fopen([PathName FileName],'r');
totalLilnes = checkFileSize(fid);
if fid == -1
    disp([PathName FileName 'does not exist.']);
    return;
end;
fileLine1 = fgetl(fid);disp(fileLine1);
fileLine2 = fgetl(fid);disp(fileLine2);
fileLine3 = fgetl(fid);disp(fileLine3);
fileLine4 = fgetl(fid);disp(fileLine4);
readLine = fgetl(fid);disp(readLine);
if strcmp(readLine,'Speaker-A anchors') ~= 1
    disp('File format is not compatible.')
    return;
end;
rawAnchor = zeros(totalLilnes,2);
lineCount = 0;
while strcmp(readLine,'Speaker-B anchors') ~= 1
    readLine = fgetl(fid);
    if ~ischar(readLine)
        disp('File is ended while still reading.')
        return;
    end;
    if strcmp(readLine,'Speaker-B anchors');break;end;
    readData = sscanf(readLine,'%f %f');
    lineCount = lineCount+1;
    rawAnchor(lineCount,:) = readData';
end;
[timeAnchorsA,frequencyAnchorsA] = ...
    rawAnchorToAnchorStructure(rawAnchor(1:lineCount,:));
rawAnchor = zeros(totalLilnes,2);
lineCount = 0;
while ischar(readLine)
    readLine = fgetl(fid);
    if ~ischar(readLine)
        break;
    end;
    readData = sscanf(readLine,'%f %f');
    lineCount = lineCount+1;
    rawAnchor(lineCount,:) = readData';
end;
[timeAnchorsB,frequencyAnchorsB] = ...
    rawAnchorToAnchorStructure(rawAnchor(1:lineCount,:));
mSubstrate.temporaAnchorOfSpeakerA = timeAnchorsA;
mSubstrate.frequencyAnchorOfSpeakerA = frequencyAnchorsA;
mSubstrate.temporaAnchorOfSpeakerB = timeAnchorsB;
mSubstrate.frequencyAnchorOfSpeakerB = frequencyAnchorsB;

yesno = menu('OK to replace anchor with this?','Yes. replace','No. cancel');
switch yesno
    case 1
        %close('templateGUIforTSmorping');
        %templateGUIforTSmorping(mSubstrate)
        okInd = mSubstrate;
    otherwise
        disp('Loading anchor is cancelled.')
        fclose(fid);
        okInd = [];
        return;
end;
fclose(fid);
return;

%  internal functions
function totalLines = checkFileSize(fid)

frewind(fid);
totalLines = 0;
readLine = fgetl(fid);
while ~ischar(readLine)
    totalLines = totalLines+1;
    readLine = fgetl(fid);
end;
frewind(fid);
return;

function [timeAnchors,frequencyAnchors] = rawAnchorToAnchorStructure(rawAnchor)

nItems = size(rawAnchor,1);
nLocations = 0;
currentLocation = -1000;
timeAnchors = zeros(nItems,1);
for ii = 1:nItems
    if currentLocation ~= rawAnchor(ii,1)
        nLocations = nLocations+1;
        currentLocation = rawAnchor(ii,1);
        timeAnchors(nLocations) = rawAnchor(ii,1);
    end;
end;
timeAnchors = timeAnchors(1:nLocations);
frequency = zeros(nLocations,20);
counts = zeros(nLocations,1);
for ii = 1:nLocations
    indexList = find(rawAnchor(:,1)==timeAnchors(ii));
    counts(ii) = length(indexList);
    tmp = sort(rawAnchor(indexList,2));
    frequency(ii,1:counts(ii)) = tmp(:)';
end;
frequencyAnchors.frequency = frequency(:,1:max(counts)+2);
if length(frequency(:,1)<0)>0
    counts(frequency(:,1)<0) = counts(frequency(:,1)<0)*0;
end;
frequencyAnchors.counts = counts;




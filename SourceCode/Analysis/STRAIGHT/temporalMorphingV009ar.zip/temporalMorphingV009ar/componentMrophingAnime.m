%%  Demonstrate independent control
%   21/Aug./2008
%   Designed and coded by Hideki Kawahara

%   load morphing object

load MobjVoical01Anch
load MobjVoical02Anch

%%  set multidimensional morphing rate

morphingRate.F0 = rand(1,1);
morphingRate.spectrum = rand(1,1);
morphingRate.aperiodicity = rand(1,1);
morphingRate.timeCoordinate = rand(1,1);
morphingRate.freqCoordinate = rand(1,1);

%%  Create morphed object

morphedObject = timeFrequencySTRAIGHTmorphingExt(MobjVoical01Anch,...
    MobjVoical02Anch,morphingRate,'log');

%%  display morphed object using dedicated function

animeBase = figure;
handles = displayMorphingStatus(morphedObject,morphingRate,animeBase);

%%  display initial morphed example

%   display

animeBase = figure;
spectrumHandle.data = displayMobjectAnime(morphedObject,'spectrogram','Morphed',animeBase,312);
maxTime = morphingRate.timeCoordinate*4100 ...
    +(1-morphingRate.timeCoordinate)*4400;
axis([0 maxTime 0 5000])
drawnow

spectrumHandle.axis = gca;

f0Handle.data = displayMobjectAnime(morphedObject,'fundamentalFrequency','Morphed',animeBase,311);
axis([0 maxTime 200 450])
%    min(morphedObject.F0(morphedObject.vuv>0))/1.1  ...
%    max(morphedObject.F0(morphedObject.vuv>0))*1.1])
drawnow

f0Handle.axis = gca;

%%  display multidimensional morphing rates

subplot(313)
temporalObj = plot([0 1],[0 1]);
axis off
axis([0 1 0 1])
set(temporalObj,'visible','off')

vLocations = 0:0.25:1;
hStartLocations = [0.2 0.45 0.3 0.35 0.33];
attributeList = {'time axis' 'fundamental frequency' 'frequency axis' ...
    'spectrogram level' 'aperiodicity level'};
for ii = 1:length(vLocations)
    line([hStartLocations(ii) 1],vLocations(ii)*[1 1],'color',[0 0.8 0.8]);
    text(0,vLocations(ii),attributeList{ii},'fontsize',18);
end;
line([0.5 0.5],[-0.07 1.07],'clipping','off','linewidth',18,'color',[0 202 10]/255);
line([1 1],[-0.07 1.07],'clipping','off','linewidth',18,'color',[0 202 10]/255);
for ii = 1:length(vLocations)
    line([0.5 1],vLocations(ii)*[1 1],'color',[255 233 4]/255,'linewidth',5, ...
        'clipping','off');
end;

text(0.42,-0.33,'singer A','fontsize',18);
text(0.92,-0.33,'singer B','fontsize',18);

%   place morphing marker
line(morphingRate.F0*0.5+0.5,vLocations(1),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
line(morphingRate.timeCoordinate*0.5+0.5,vLocations(2),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
line(morphingRate.freqCoordinate*0.5+0.5,vLocations(3),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
line(morphingRate.spectrum*0.5+0.5,vLocations(4),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
line(morphingRate.aperiodicity*0.5+0.5,vLocations(5),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
%morphingRate.spectrum = 0;
%morphingRate.aperiodicity = 0;
%morphingRate.timeCoordinate = 0;
%morphingRate.freqCoordinate = 0;



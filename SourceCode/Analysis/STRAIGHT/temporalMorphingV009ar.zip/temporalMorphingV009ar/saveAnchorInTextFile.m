function okInd = saveAnchorInTextFile(mSubstrate)
%   okInd = saveAnchorInTextFile(mSubstrate)

%   06/Nov./2008
%   by Hideki Kawahara

temporaAnchorOfSpeakerA = mSubstrate.temporaAnchorOfSpeakerA;
temporaAnchorOfSpeakerB = mSubstrate.temporaAnchorOfSpeakerB;
frequencyAnchorDataOfSpeakerA = mSubstrate.frequencyAnchorOfSpeakerA.frequency;
frequencyAnchorDataOfSpeakerB = mSubstrate.frequencyAnchorOfSpeakerB.frequency;
frequencyAnchorCountOfSpeakerA = mSubstrate.frequencyAnchorOfSpeakerA.counts;
frequencyAnchorCountOfSpeakerB = mSubstrate.frequencyAnchorOfSpeakerB.counts;

outFileName = ['anchors' datestr(now,30) '.txt'];
[file,path] = uiputfile(outFileName,'Save anchor information as a text file');
if length(file) == 1 && length(path) == 1
    if file == 0 || path == 0
        okInd = 0;
        disp('Save is cancelled!');
        return;
    end;
end;
numberOfTimeAnchors = length(temporaAnchorOfSpeakerA);
fid = fopen([path file],'w');
fprintf(fid,'dataDirectoryForSpeakerA: %s\n',mSubstrate.dataDirectoryForSpeakerA);
fprintf(fid,'dataDirectoryForSpeakerB: %s\n',mSubstrate.dataDirectoryForSpeakerB);
fprintf(fid,'fileNameForSpeakerA: %s\n',mSubstrate.fileNameForSpeakerA);
fprintf(fid,'fileNameForSpeakerB: %s\n',mSubstrate.fileNameForSpeakerB);
fprintf(fid,'Speaker-A anchors\n');
for ii = 1:numberOfTimeAnchors
    if frequencyAnchorCountOfSpeakerA(ii) == 0
        fprintf(fid,'%12.3f %6.0f\n',temporaAnchorOfSpeakerA(ii), -100);
    else
        for jj = 1:frequencyAnchorCountOfSpeakerA(ii)
            fprintf(fid,'%12.3f %6.0f\n',temporaAnchorOfSpeakerA(ii),frequencyAnchorDataOfSpeakerA(ii,jj));
        end;
    end;
end;
fprintf(fid,'Speaker-B anchors\n');
for ii = 1:numberOfTimeAnchors
    if frequencyAnchorCountOfSpeakerB(ii) == 0
        fprintf(fid,'%12.3f %6.0f\n',temporaAnchorOfSpeakerB(ii), -100);
    else
        for jj = 1:frequencyAnchorCountOfSpeakerB(ii)
            fprintf(fid,'%12.3f %6.0f\n',temporaAnchorOfSpeakerB(ii),frequencyAnchorDataOfSpeakerB(ii,jj));
        end;
    end;
end;
fclose(fid);
okInd = 1;


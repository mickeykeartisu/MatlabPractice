function mSubstrateOut = mSubstrateViewer(mSubstrate,actionString)

if ~isfield(mSubstrate,'viewer')
    mSubstrateOut = mSubstrate;
elseif isempty(mSubstrate.viewer)
    mSubstrateOut = mSubstrate;
else
    mSubstrateOut = get(mSubstrate.viewer,'userdata');
end;
fs = mSubstrate.samplintFrequency;
upperFrequencyLimit = 6000;
figureWidth = 1000; %pixcels
figureHeight = 648; %pixcels

switch actionString
    case 'initialize'
        figureHandle = figure;
        mSubstrateOut.viewer = figureHandle;
        set(figureHandle,'userdata',mSubstrateOut);
        %currentPosition = get(figureHandle,'Position');
        set(figureHandle,'Position',[20 300 figureWidth figureHeight]);
        displaySpec.upperFrequency = 6000;
displaySpec.displayAttribute = 'spectrogram';
displaySpec.spectralDynamicRange = 70; % in dB
displaySpec.itemToBeDisplayed = 'speakerA';
        subplot(221);showSpecgram(mSubstrate,displaySpec)
        displaySpec.itemToBeDisplayed = 'speakerB';
        subplot(222);showSpecgram(mSubstrate,displaySpec)
end;

function showSpecgram(mSubstrate,displaySpec)

fs = mSubstrate.samplintFrequency;
upperFrequencyLimit = 6000;

switch displaySpec.itemToBeDisplayed
    case 'speakerA'
        timeAxis = mSubstrate.spectrogramTimeBaseOfSpeakerA;
        sgramSTRAIGHT = mSubstrate.STRAIGHTspectrogramOfSpeakerA;
        if ~isempty(mSubstrate.temporaAnchorOfSpeakerA)
            temporalAnchor = mSubstrate.temporaAnchorOfSpeakerA;
        end;
    case 'speakerB'
        timeAxis = mSubstrate.spectrogramTimeBaseOfSpeakerB;
        sgramSTRAIGHT = mSubstrate.STRAIGHTspectrogramOfSpeakerB;
        if ~isempty(mSubstrate.temporaAnchorOfSpeakerA)
            temporalAnchor = mSubstrate.temporaAnchorOfSpeakerB;
        end;
end;
sgramSTRAIGHT = 10*log10(sgramSTRAIGHT);
sgramSTRAIGHT = max(max(max(sgramSTRAIGHT))...
    -displaySpec.spectralDynamicRange, sgramSTRAIGHT);
imagesc([0 timeAxis(end)],[0 fs/2], ...
    sgramSTRAIGHT);axis('xy');
hold on
for ii = 1:length(temporalAnchor)
    anchorObj = plot(temporalAnchor(ii)*[1 1 1],[0 upperFrequencyLimit ...
        max(upperFrequencyLimit,fs/2)],'w');
    set(anchorObj,'userdata',ii);
    text(temporalAnchor(ii),upperFrequencyLimit*1.02,...
        char(rem(ii-1,26)+1+64));
end;
axis([0 timeAxis(end) 0 upperFrequencyLimit]);
set(gca,'fontsize',13);
xlabel(['time (s) of '  displaySpec.itemToBeDisplayed])
ylabel('frequency (Hz)');
%title(displaySpec.itemToBeDisplayed);
hold off
drawnow;
return;

function displayConversionFunction

if isempty(findobj(0,'Tag','distanceViewer','-depth',1))
    distanceViewerFigure = figure('Tag','distanceViewer');
else
    distanceViewerFigure = findobj(0,'Tag','distanceViewer','-depth',1);
end;
figure(distanceViewerFigure);
spectralSectionHandle = findobj('Tag','SpectralSection');
if isempty(spectralSectionHandle)
    disp('SpectralSection cannot be found');
    return;
end;
axisUserdata = get(spectralSectionHandle,'userdata');
frequencyAxis = get(axisUserdata.logSpecAHandle,'xdata');
logSpecA = get(axisUserdata.logSpecAHandle,'ydata');
logSpecB = get(axisUserdata.logSpecBHandle,'ydata');
upperEnd = frequencyAxis(end);
%subplot(211);
h = figure;
semilogx(frequencyAxis,logSpecA,frequencyAxis,logSpecB,'r');
axis([100 frequencyAxis(end) max([logSpecA(:); logSpecB(:)])+[-80 5]]);
grid on;
nFormants = axisUserdata.numberOfFrequencyAnchors;
if nFormants > 0
    rawAnchorA = zeros(nFormants,1);
    rawAnchorB = zeros(nFormants,1);
    for ii = 1:nFormants
        rawAnchorA(ii) = ...
            get(axisUserdata.frequencyPointObj.markAHandle(ii),'xdata');
        rawAnchorB(ii) = ...
            get(axisUserdata.frequencyPointObj.markBHandle(ii),'xdata');
    end;
    extendedAnchorsForA = [0;rawAnchorA;upperEnd];
    extendedAnchorsForB = [0;rawAnchorB;upperEnd];
    frequencyAxisOfAonB = interp1(extendedAnchorsForA,extendedAnchorsForB, ...
        frequencyAxis,'linear','extrap');
    logSpecBonA = interp1(frequencyAxis,logSpecB,frequencyAxisOfAonB);
else
    logSpecBonA = logSpecB;
end;
hold on;
semilogx(frequencyAxis,logSpecBonA,'g');
hold off;

lowerLimit = 100; % consider only higher than 100 Hz
[dmy,lowerIndex]=min(abs(frequencyAxis-lowerLimit));
ebx = lowerIndex:length(frequencyAxis);
linearDBdistortortion = std(logSpecBonA(ebx)-logSpecA(ebx))

erbWeight = 21.4/log(10)./(frequencyAxis*0.00437+1);
weightedMeanA = sum(erbWeight(ebx).*logSpecA(ebx))/sum(erbWeight(ebx));
weightedMeanB = sum(erbWeight(ebx).*logSpecBonA(ebx))/sum(erbWeight(ebx));
weightedDifferenceVector = erbWeight(ebx).*((logSpecA(ebx)-weightedMeanA)- ...
    (logSpecBonA(ebx)-weightedMeanB));
erbDBdistortion2 = sqrt(sum(weightedDifferenceVector.^2)/sum(erbWeight(ebx).^2))

%   cosine series on the ERB=n rate axis

weightedMeanA = sum(erbWeight.*logSpecA)/sum(erbWeight);
weightedMeanB = sum(erbWeight.*logSpecBonA)/sum(erbWeight);
differenceVector = (logSpecA-weightedMeanA)-(logSpecBonA-weightedMeanB);
nTerm = 5;
ERBaxis = 21.4*log10(frequencyAxis*0.00437+1);
normalizedERBaxis = pi*(ERBaxis-ERBaxis(1))/(ERBaxis(end)-ERBaxis(1));
cosBasisFunction = zeros(length(ERBaxis),nTerm);
for ii = 1:nTerm
    cosBasisFunction(:,ii) = cos(ii*normalizedERBaxis(:));
end;
figure;semilogx(frequencyAxis(ebx),cosBasisFunction(ebx,:));grid on;
axis([frequencyAxis(ebx(1)) frequencyAxis(ebx(end)) -1 1]);
%coefficients = weightedDifferenceVector*cosBasisFunction;
coefficients = (erbWeight.*differenceVector)*cosBasisFunction;
coefficientsNormal = coefficients/sum(erbWeight);
smoothedDifference = ...
    2*sum((cosBasisFunction(:,1:nTerm)*diag(coefficientsNormal(1:nTerm)))');
fixedDifference = differenceVector-smoothedDifference;
modifiedBonA = logSpecA-fixedDifference;
figure(h)
hold on;
semilogx(frequencyAxis(ebx),modifiedBonA(ebx),'k');
hold off





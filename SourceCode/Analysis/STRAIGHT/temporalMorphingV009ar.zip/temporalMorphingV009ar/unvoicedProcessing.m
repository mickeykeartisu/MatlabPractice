function processedSpectrum = unvoicedProcessing(STRAIGHTobject)

averagingWidth = 0.025;
x = STRAIGHTobject.waveform;
fs = STRAIGHTobject.samplingFrequency;
locations = STRAIGHTobject.refinedF0Structure.temporalPositions;
originalSpectrum = STRAIGHTobject.SpectrumStructure.spectrogramSTRAIGHT;
vuv = STRAIGHTobject.refinedF0Structure.vuv;
deltaT = locations(2);
nFrames = ceil(averagingWidth/deltaT);
nFrames = 2*max(1,round(nFrames/2))+1;
halfLength = (nFrames-1)/2;
w = ones(nFrames,1);

processedSpectrum = originalSpectrum;
for ii = 1:length(locations)
    processedSpectrum(:,ii) = processedSpectrum(:,ii)*(1-vuv(ii));
end;
processedSpectrum = [processedSpectrum zeros(size(processedSpectrum,1),nFrames)];
processedSpectrum = abs(fftfilt(w,processedSpectrum'))';
processedSpectrum = processedSpectrum(:,halfLength+(1:length(locations)));

targetLevel = sum(originalSpectrum);
initialLevel = sum(processedSpectrum);

for ii = 1:length(locations)
    if (vuv(ii) == 0) && (initialLevel(ii) >0)
        processedSpectrum(:,ii) = processedSpectrum(:,ii)/initialLevel(ii)*targetLevel(ii);
    else
        processedSpectrum(:,ii) = originalSpectrum(:,ii);
    end;
end;

%%  Demonstrate independent control
%   21/Aug./2008
%   Designed and coded by Hideki Kawahara

%   24/Aug./2008 enable background

%   load morphing object

load MobjVoical01Anch
load MobjVoical02Anch

%%  set multidimensional morphing rate

% (1) time Axis, (2) F0, (3) freq Axis, (4) spect level, (5) aperiod level

startPattern = [0 0 0 0 0];
endPattern = [1 1 1 1 1];

%%  scan morphing rates

targetDirectory = ['mdMorphGS' num2str(startPattern*10,'%02.2d') ...
    'E' num2str(endPattern*10,'%02.2d')];
mkdir(targetDirectory)
animeBase = figure;
set(gcf,'InvertHardcopy','off');

for globalRate = 0:0.05:1

    morphedPattern = (1-globalRate)*startPattern+globalRate*endPattern;

    morphingRate.timeCoordinate = morphedPattern(1);
    morphingRate.F0 = morphedPattern(2);
    morphingRate.freqCoordinate = morphedPattern(3);
    morphingRate.spectrum = morphedPattern(4);
    morphingRate.aperiodicity = morphedPattern(5);

    %  Create morphed object

    morphedObject = timeFrequencySTRAIGHTmorphingExt(MobjVoical01Anch,...
        MobjVoical02Anch,morphingRate,'log');

    %  display morphed object using dedicated function

    handles = displayMorphingStatus(morphedObject,morphingRate,animeBase);


    outFileName1 = ...
        ['Mdfig' num2str(round(globalRate*100),'%04.4d') '.png'];
    outFileName2 = ...
        ['Mdfig' num2str(round((2-globalRate)*100),'%04.4d') '.png'];
    h1 = text(0,-0.33,num2str(num2str(globalRate,'%03.2f')));
    drawnow
    eval(['print -dpng -r150 ' targetDirectory '/' outFileName1]);
    eval(['print -dpng -r150 ' targetDirectory '/' outFileName2]);
end;

%%  generate sound for target frame

globalRate = 0.5;
morphedPattern = (1-globalRate)*startPattern+globalRate*endPattern;

targetDirectory = ['mdMorphGE' num2str(round(morphedPattern*100),'%03.3d')];
mkdir(targetDirectory)
animeBase = figure;
set(gcf,'InvertHardcopy','off')

morphingRate.timeCoordinate = morphedPattern(1);
morphingRate.F0 = morphedPattern(2);
morphingRate.freqCoordinate = morphedPattern(3);
morphingRate.spectrum = morphedPattern(4);
morphingRate.aperiodicity = morphedPattern(5);

morphedObject = timeFrequencySTRAIGHTmorphingExt(MobjVoical01Anch,...
    MobjVoical02Anch,morphingRate,'log');

handles = displayMorphingStatus(morphedObject,morphingRate,animeBase);
maxTime = morphedPattern(1)*4100+(1-morphedPattern(1))*4400;
text(0,-0.33,num2str(round(morphedPattern*100),'%03.3d'));

endSampleLocation = round(maxTime/1000*morphedObject.samplingFrequency);

syOut = executeSTRAIGHTsynthesisM(morphedObject);
syOut = syOut(1:endSampleLocation);

synthesisOutFileName = ['synMorph' num2str(round(morphedPattern*100),'%03.3d') '.wav'];
wavwrite(syOut/std(syOut)*0.07,morphedObject.samplingFrequency,16,synthesisOutFileName);

%close(animeBase);

%%  repeatedly output target frame

ii = 0;
currentTime = 0;
figure(animeBase);
subplot(312)
hold on;
hh2 = line(currentTime*[1 1]*1000,[-200 5200],'clipping','off',...
    'color',[1 0 0],'linewidth',7)
hh = plot(currentTime*[1 1]*1000,[0 5000],'y','linewidth',3);
subplot(311)
yLimit = get(gca,'ylim');
hold on;
hh3 = line(currentTime*[1 1]*1000,[180 470],'clipping','off',...
    'color',[1 0 0],'linewidth',7)
hh4 = plot(currentTime*[1 1]*1000,[200 450],'y','linewidth',3);
for currentTime = 0:1/30:maxTime/1000
    ii = ii+1;
    set(hh,'xdata',currentTime*[1 1]*1000);
    set(hh2,'xdata',currentTime*[1 1]*1000);
    set(hh3,'xdata',currentTime*[1 1]*1000);
    set(hh4,'xdata',currentTime*[1 1]*1000);
    drawnow
    outFileName = ['MAnime' num2str(endPattern*10,'%02.2d') ...
        'fr' num2str(ii,'%04.4d') '.png'];
    drawnow
    eval(['print -dpng -r150 ' targetDirectory '/' outFileName]);
end;
set(hh,'visible','off');
set(hh2,'visible','off');
set(hh3,'visible','off');
set(hh4,'visible','off');
hold off
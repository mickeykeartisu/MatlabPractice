%%%---- supporting GUI functions by user

function timeAnchorCallback(varargin)

if size(varargin,2) > 0
    objectHandel = varargin{:};
else
    objectHandel = gco;
end;
%objectHandel = gco;
if strcmp(get(objectHandel,'tag'),'timeAnchors')
    anchorNumber = get(objectHandel,'userdata');
    %disp(['Yes! time anchor' num2str(anchorNumber)])
    parentAxisHandle = get(objectHandel,'parent');
    %axisUserData = get(parentAxisHandle,'userdata');
    parentFigureHandle = get(parentAxisHandle,'parent');
    figureUserData = get(parentFigureHandle,'userdata');
    objectHandles = figureUserData.handleInfo;
    %sectionUserData = get(objectHandles.SpectralSection,'userdata');
    mSubstrate = figureUserData.inputData;
    nFormants = mSubstrate.frequencyAnchorOfSpeakerA.counts(anchorNumber);
    set(objectHandles.frequencyAnchors,'value',nFormants+1);
    speakerAuserData = get(figureUserData.handleInfo.SpeakerA,'userdata');
    speakerBuserData = get(figureUserData.handleInfo.SpeakerB,'userdata');
    if figureUserData.selectedItem == anchorNumber
        updatedAnchorA = ...
            get(speakerAuserData.anchorObj.timeAnchor(anchorNumber),'xdata');
        mSubstrate.temporaAnchorOfSpeakerA(anchorNumber) = updatedAnchorA(1);
        updatedAnchorB = ...
            get(speakerBuserData.anchorObj.timeAnchor(anchorNumber),'xdata');
        mSubstrate.temporaAnchorOfSpeakerB(anchorNumber) = updatedAnchorB(1);
        figureUserData.inputData = mSubstrate;
        set(parentFigureHandle,'userdata',figureUserData);
    else
        set(speakerAuserData.anchorObj.timeAnchor(figureUserData.selectedItem),...
            'xdata',mSubstrate.temporaAnchorOfSpeakerA(figureUserData.selectedItem)...
            *[1 1 1]);
        set(speakerBuserData.anchorObj.timeAnchor(figureUserData.selectedItem),...
            'xdata',mSubstrate.temporaAnchorOfSpeakerB(figureUserData.selectedItem)...
            *[1 1 1]);
    end;
    set(objectHandles.TimeA,'string',...
        num2str(mSubstrate.temporaAnchorOfSpeakerA(anchorNumber),'%06.4f'));
    set(objectHandles.TimeB,'string',...
        num2str(mSubstrate.temporaAnchorOfSpeakerB(anchorNumber),'%06.4f'));
    set(objectHandles.TimeAdjustA,'value',0);
    set(objectHandles.TimeAdjustB,'value',0);
    displaySpec.selectedItem = anchorNumber;
    displaySpec.axisHandle = figureUserData.handleInfo.SpectralSection;
    updateCrossSections(mSubstrate,displaySpec);
    set(speakerAuserData.anchorObj.timeAnchor(figureUserData.selectedItem),'Marker','none','linewidth',0.5);
    set(speakerAuserData.anchorObj.timeAnchor(anchorNumber),'Marker','s','linewidth',1.5);
    set(speakerBuserData.anchorObj.timeAnchor(figureUserData.selectedItem),'Marker','none','linewidth',0.5);
    set(speakerBuserData.anchorObj.timeAnchor(anchorNumber),'Marker','s','linewidth',1.5);
    figureUserData.selectedItem = anchorNumber;
    set(parentFigureHandle,'userdata',figureUserData);
    axisUserData = get(objectHandles.SpectralSection,'userdata');
    frequencyAnchorCallback(axisUserData.frequencyPointObj.lineAHandle(1));
else
    disp('this is not a time anchors')
end;

%%%---- supporting internal function

function updateCrossSections(mSubstrate,displaySpec)

crossSectionUserData = get(displaySpec.axisHandle,'userdata');

anchorIndex = displaySpec.selectedItem;
[dmy,iTime] = min(abs(mSubstrate.spectrogramTimeBaseOfSpeakerA- ...
    mSubstrate.temporaAnchorOfSpeakerA(anchorIndex)));
logSpecA = 10*log10(mSubstrate.STRAIGHTspectrogramOfSpeakerA(:,iTime));
set(crossSectionUserData.logSpecAHandle,'ydata',logSpecA);
[dmy,iTime] = min(abs(mSubstrate.spectrogramTimeBaseOfSpeakerB- ...
    mSubstrate.temporaAnchorOfSpeakerB(anchorIndex)));
logSpecB = 10*log10(mSubstrate.STRAIGHTspectrogramOfSpeakerB(:,iTime));
set(crossSectionUserData.logSpecBHandle,'ydata',logSpecB);
set(displaySpec.axisHandle,'ylim',max([logSpecA;logSpecB])+5-[1 0]*70);

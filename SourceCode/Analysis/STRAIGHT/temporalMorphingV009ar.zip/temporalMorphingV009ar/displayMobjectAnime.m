function displayHandle = displayMobjectAnime(mObject,fieldname,note,figureHandle,subPlotId)
%   M-object information display
%   for visualization
%   displayHandle = displayMobjectAnime(mObject,fieldname,note,figureHandle,subPlotId)

%   Designed and coded by Hideki Kawahara
%   27/Feb./2005
%   Copyright(c) 2005, Hideki Kawahara
%   05/Oct./2005 minor bug fix
%   05/Aug./2008
%   21/Aug./2008 Handle to graphics is added

fs = mObject.samplingFrequency;
tFrame = mObject.frameUpdateInterval;
switch fieldname
    case 'spectrogram'
        figure(figureHandle)
        subplot(subPlotId)
        [nrow,ncolumn]=size(mObject.spectrogram);
        timeSpan = [0 (ncolumn-1)*tFrame];
        dBsgram = 20*log10(mObject.spectrogram);
        maxSgramdB = max(max(dBsgram));
        spectrogramHandle = imagesc(timeSpan, [0 fs/2],max(dBsgram,maxSgramdB-70));
        if nargout == 1; displayHandle = spectrogramHandle;end;
        axis('xy');
        set(gca,'fontsize',14);
        xlabel('time (ms)');
        ylabel('frequency (Hz)');
        %title([note ' time span 0 ' num2str(timeSpan(2),10) ' (ms) ' datestr(now)]);
    case 'waveform'
        figure(figureHandle)
        subplot(subPlotId)
        x = mObject.waveform;
        timeSpan = (0:length(x)-1)/fs*1000;
        waveformHandle = plot(timeSpan,x);grid on;
        if nargout == 1; displayHandle = waveformHandle;end;
        axis([timeSpan(1) timeSpan(end) 1.1*[min(x) max(x)]]);
        set(gca,'fontsize',14);
        xlabel('time (ms)');
        title([note ' time span 0 ' num2str(round(timeSpan(end)),8) ' (ms) ' datestr(now)]);
    case 'fundamentalFrequency'
        figure(figureHandle)
        subplot(subPlotId)
        nFrames = size(mObject.F0,1);
        x = mObject.F0;
        vuv = mObject.vuv;
        x(vuv==0) = x(vuv==0)*NaN;
        timeSpan = (0:nFrames-1)'*tFrame;
        f0Handle = plot(timeSpan,x);grid on;
        if nargout == 1; displayHandle = f0Handle;end;
        axis([timeSpan(1) timeSpan(end) 0.9*min(x(vuv>0)) 1.1*max(x(vuv>0))]);
        set(gca,'fontsize',14);
        xlabel('time (ms)');
        ylabel('F0 (Hz)');
    case {'anchorFrequency', 'anchorTimeLocation'}
        figure(figureHandle)
        subplot(subPlotId)
        [nrow,ncolumn]=size(mObject.spectrogram);
        timeSpan = [0 (ncolumn-1)*tFrame];
        dBsgram = 20*log10(mObject.spectrogram);
        maxSgramdB = max(max(dBsgram));
        spectrogramHandle = imagesc(timeSpan, [0 fs/2],max(dBsgram,maxSgramdB-70));
        if nargout == 1; displayHandle = spectrogramHandle;end;
        axis('xy');
        set(gca,'fontsize',14);
        xlabel('time (ms)');
        ylabel('frequency (Hz)');
        %title([note ' time span 0 ' num2str(timeSpan(2),10) ' (ms) ' datestr(now)]);
        if length(mObject.anchorTimeLocation)>0
            hold on;
            for ii=1:length(mObject.anchorTimeLocation)
                hh = plot(mObject.anchorTimeLocation(ii)*[1 1],[0 fs/2],'w:');
                set(hh,'linewidth',2);
                if sum(mObject.anchorFrequency(ii,:)>0)>0
                    nFrequency = sum(mObject.anchorFrequency(ii,:)>0);
                    anchorFrequencyVector = mObject.anchorFrequency(ii,mObject.anchorFrequency(ii,:)>0); % 05/Oct./2005 HK
                    for jj=1:nFrequency
                        hh=plot(mObject.anchorTimeLocation(ii),anchorFrequencyVector(jj),'ok');
                        set(hh,'markersize',9);
                        set(hh,'linewidth',2);
                        hh=plot(mObject.anchorTimeLocation(ii),anchorFrequencyVector(jj),'.w');
                        set(hh,'markersize',7);
                        set(hh,'linewidth',4);
                    end;
                end;
            end;
            hold off;
        end;
end;
if nargout ~= 1
    return;
end;




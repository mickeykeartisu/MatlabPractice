%%  program based interface for temporal definition of morphing rate
%   Designed and coded by Hideki Kawahara
%   09/Nov./2008

echo on
%   first of all, set morphing substrate on the menu

menuHandle = MorphingMenu;

% This invokes a menu with blank morphing substrate. It is necessary to
% load existing morphing substrate or make a morphing substrate starting
% from two exemplar files. After analyzing files or importing analysis results,
% you have to fetch label file for each speech. 
% (If you do not have label files, you can skip this step.)
% Then, finally, you have to initialize time axis for
% morping. The default time axis form morphing is set to that of the
% speaker A. At this point, you can invoke the interactive editing
% interface for anchors and resynthesize speech from defined morphing
% rates.
%
% After completing these steps, you can redefine the time varying morphing
% rate using the following script under "cell mode".

echo off
return;

%%  make morphing rates accessible
%
%   This cell is necessary for command line mode to be accessible to the
%   morphing substrate under investigation.

userData = get(menuHandle,'userdata');
mSubstrate = userData.mSubstrate;
mRate = mSubstrate.temporalMorphingRate;
morphingTimeAxis = mSubstrate.morphingTimeAxis(:);

%%   linear function 
%   You can design any functios using this example

normalizedTime = (mSubstrate.morphingTimeAxis(:))/mSubstrate.morphingTimeAxis(end);
timeFunction = min(1,max(0,-(normalizedTime-0.5)*0+1));
mRate.time = timeFunction;
mRate.F0 = timeFunction;
mRate.frequency = timeFunction;
mRate.spectrum = timeFunction;
mRate.aperiodicity = timeFunction;

figure;plot(mSubstrate.morphingTimeAxis,timeFunction);grid on;
%%  This is another more flexible design

normalizedTime = (mSubstrate.morphingTimeAxis(:))/mSubstrate.morphingTimeAxis(end);
designLocations = [0.0 0.2 0.4 0.6 0.8 1.0]';
designMixRate =   [0.0 0.1 1.0 1.0 0.1 0.0]';
timeFunction = interp1(designLocations,designMixRate,normalizedTime);
mRate.time = timeFunction;
mRate.F0 = timeFunction;
mRate.frequency = timeFunction;
mRate.spectrum = timeFunction;
mRate.aperiodicity = timeFunction;

figure;plot(mSubstrate.morphingTimeAxis,timeFunction);grid on;

%%  update morphing rate
%
%   This section is necessary for the edited morphing rates to be
%   effective.

mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','temporalMorphingRate',mRate);
userData.mSubstrate = mSubstrate;
set(menuHandle,'userdata',userData);

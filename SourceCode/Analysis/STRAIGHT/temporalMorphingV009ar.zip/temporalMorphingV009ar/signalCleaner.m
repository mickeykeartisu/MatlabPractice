function OutputSignalStructure = signalCleaner(operation,InputSignalStructure)

OutputSignalStructure = InputSignalStructure;
fs = InputSignalStructure.samplingFrequency;
x = InputSignalStructure.waveform;
f0 = InputSignalStructure.f0;
vuv = InputSignalStructure.vuv;

fftl = 2.0.^ceil(log2(size(x,1)));
fx = (0:fftl-1)'/fftl*fs;
medianF0 = median(f0(vuv>0));
fftSpectrum = fft(x,fftl);
fftBinStep = fx(2);
cumulatedPower = cumsum(abs(fftSpectrum).^2);
h1MedianLevel = cumulatedPower(round(medianF0/fftBinStep)+1);
lowerNoiseLevel = cumulatedPower(round(medianF0/2/fftBinStep)+1);
OutputSignalStructure.medianF0 = medianF0;
OutputSignalStructure.h1HalfPower = ...
    10*log10(h1MedianLevel-lowerNoiseLevel);
OutputSignalStructure.lowerNoiseLevel = 10*log10(lowerNoiseLevel);
switch operation
    case 'check'
        OutputSignalStructure.frequencyAxis = fx;
        OutputSignalStructure.fftSpectrum = fftSpectrum;
    case {'fix','clean'}
        %display('not implemented yet')
        y = f0MedianBasedHPF(fftSpectrum,fx,medianF0);
        OutputSignalStructure.waveform = y(1:length(x));
        OutputSignalStructure.cleaning = 'done';
    otherwise
        display('valid operations are: check, fix and clean.')
        OutputSignalStructure = [];
end;

function y = f0MedianBasedHPF(fftSpectrum,fx,medianF0)

fftl = length(fftSpectrum);
fftBinStep = fx(2);
upperBinID = round(2*medianF0/fftBinStep)+1;
shaper = 1.0./(1+exp(-40*(fx(1:upperBinID)-medianF0/2.5)/medianF0));
fftSpectrum(1:upperBinID) = fftSpectrum(1:upperBinID).*shaper;
fftSpectrum(fftl-(0:upperBinID-2)) = ...
    fftSpectrum(fftl-(0:upperBinID-2)).*shaper(2:upperBinID);
y = real(ifft(fftSpectrum));





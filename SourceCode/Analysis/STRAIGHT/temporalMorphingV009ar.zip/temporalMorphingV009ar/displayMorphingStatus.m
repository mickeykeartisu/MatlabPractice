function handles = displayMorphingStatus(morphedObject,morphingRate,animeBase)
%   handles = displayMorphingStatus(morphedObject,morphingRate,animeBase)

%   Designed and coded by Hideki Kawahara
%   22/Aug./2008

figure(animeBase)
handles.figureHandle = gcf;

%morphedObject = timeFrequencySTRAIGHTmorphingExt(MobjVoical01Anch,...
%    MobjVoical02Anch,morphingRate,'log');
spectrumHandle.data = displayMobjectAnime(morphedObject,'spectrogram','Morphed',animeBase,312);
maxTime = morphingRate.timeCoordinate*4100 ...
    +(1-morphingRate.timeCoordinate)*4400;
axis([0 maxTime 0 5000])
drawnow

handles.spectrumHandleAxis = gca;
handles.spectrumHandleData = spectrumHandle.data;

f0Handle.data = displayMobjectAnime(morphedObject,'fundamentalFrequency','Morphed',animeBase,311);
axis([0 maxTime 200 450])
drawnow

handles.f0HandleAxis = gca;
handles.f0HandleData = f0Handle.data;

%  display multidimensional morphing rates

subplot(313)
temporalObj = plot([0 1],[0 1]);
axis off
axis([0 1 0 1])
handles.panelAxis = gca;
set(temporalObj,'visible','off')

vLocations = 0:0.25:1;
hStartLocations = [0.2 0.45 0.3 0.35 0.33];
attributeList = {'time axis' 'fundamental frequency' 'frequency axis' ...
    'spectrogram level' 'aperiodicity level'};
for ii = 1:length(vLocations)
    line([hStartLocations(ii) 1],vLocations(ii)*[1 1],'color',[0 0.8 0.8], ...
        'linewidth',2,'clipping','off');
    text(0,vLocations(ii),attributeList{ii},'fontsize',18);
end;
line([0.5 0.5],[-0.075 1.075],'clipping','off','linewidth',18,'color',[0 202 10]/255);
line([1 1],[-0.075 1.075],'clipping','off','linewidth',18,'color',[0 202 10]/255);
for ii = 1:length(vLocations)
    line([0.5 1],vLocations(ii)*[1 1],'color',[255 233 4]/255,'linewidth',5, ...
        'clipping','off');
end;

text(0.42,-0.33,'singer A','fontsize',18);
text(0.92,-0.33,'singer B','fontsize',18);

%   place morphing marker
handles.timeCoordinate = line(morphingRate.timeCoordinate*0.5+0.5,vLocations(1),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
handles.F0 = line(morphingRate.F0*0.5+0.5,vLocations(2),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
handles.freqCoordinate = line(morphingRate.freqCoordinate*0.5+0.5,vLocations(3),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
handles.spectrum = line(morphingRate.spectrum*0.5+0.5,vLocations(4),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
handles.aperiodicity = line(morphingRate.aperiodicity*0.5+0.5,vLocations(5),...
    'clipping','off','linewidth',4,'marker','.','markeredgecolor',[0 0 1],...
    'markersize',50);
drawnow
return;

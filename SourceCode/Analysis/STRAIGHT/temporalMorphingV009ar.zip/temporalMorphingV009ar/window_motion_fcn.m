function window_motion_test
%
figure('WindowButtonDownFcn',@wbdcb)
ah = axes('DrawMode','fast');
axis ([1 10 1 10])
title('Click and drag')
    function wbdcb(src,evnt)
        if strcmp(get(src,'SelectionType'),'normal')
            set(src,'pointer','circle')
            cp = get(ah,'CurrentPoint');
            xinit = cp(1,1);yinit = cp(1,2);
            hl = line('XData',xinit,'YData',yinit,...
                'Marker','p','color','b','linewidth',5);
            set(src,'WindowButtonMotionFcn',@wbmcb)
            set(src,'WindowButtonUpFcn',@wbucb)
        end

        function wbmcb(src,evnt)
            cp = get(ah,'CurrentPoint');
            xdat = [xinit,cp(1,1)];
            ydat = [yinit,cp(1,2)];
            set(hl,'XData',xdat,'YData',ydat);drawnow
        end

        function wbucb(src,evnt)
            if strcmp(get(src,'SelectionType'),'alt')
                set(src,'Pointer','arrow')
                set(src,'WindowButtonMotionFcn','')
                set(src,'WindowButtonUpFcn','')
            else
                return
            end
        end
    end
end
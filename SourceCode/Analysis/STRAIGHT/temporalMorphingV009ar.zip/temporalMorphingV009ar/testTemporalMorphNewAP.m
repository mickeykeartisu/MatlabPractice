%%  Test program for temporal axis morphing
%   by Hideki Kawahara
%   26/Aug./2008
%   31/Aug./2008
%   03/Sept./2008
%   21/Oct./2008 revised for new aperiodicity parameter
%   06/Nov./2008 cleaned up

datestr(now)

%dataDirectoryForSpeakerA = '../ANNYSTRAIGHT/testData/';
%dataDirectoryForSpeakerB = '../ANNYSTRAIGHT/testData/';
dataDirectoryForSpeakerA = './';
dataDirectoryForSpeakerB = './';
fileNameForSpeakerA = 'aiueoL.wav';
fileNameForSpeakerB = 'aiueoF2.wav';

[xA,fs1] = wavread([dataDirectoryForSpeakerA fileNameForSpeakerA]);
[xB,fs] = wavread([dataDirectoryForSpeakerB fileNameForSpeakerB]);
if fs1 ~= fs
    disp(['sampling frequencies of A and B are ' ...
        num2str(fs1) ' (Hz) and ' num2str(fs1) ' (Hz). Is this OK?']);
end;

%%  extract source infromation

rA = exF0candidatesTSTRAIGHTGB(xA,fs)
rB = exF0candidatesTSTRAIGHTGB(xB,fs)

%%  spectrum estimation

fA = exSpectrumTSTRAIGHTGB(xA,fs,rA)
fB = exSpectrumTSTRAIGHTGB(xB,fs,rB)

%%  aperiodicity

qA = aperiodicityRatio(xA,rA,2)
qB = aperiodicityRatio(xB,rB,2)

%%  create morphing substrate

mSubstrate = morphingSubstrateNewAP;
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'samplintFrequency',rA.samplingFrequency);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','dataDirectoryForSpeakerA',...
    dataDirectoryForSpeakerA);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','dataDirectoryForSpeakerB',...
    dataDirectoryForSpeakerB);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','fileNameForSpeakerA',...
    fileNameForSpeakerA);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','fileNameForSpeakerB',...
    fileNameForSpeakerB);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','f0OfSpeakerA',rA.f0);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'f0TimeBaseOfSpeakerA',rA.temporalPositions);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','f0OfSpeakerB',rB.f0);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'f0TimeBaseOfSpeakerB',rB.temporalPositions);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'STRAIGHTspectrogramOfSpeakerA',fA.spectrogramSTRAIGHT);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'spectrogramTimeBaseOfSpeakerA',fA.temporalPositions);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'STRAIGHTspectrogramOfSpeakerB',fB.spectrogramSTRAIGHT);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'spectrogramTimeBaseOfSpeakerB',fB.temporalPositions);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'aperiodicityOfSpeakerA',qA);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'aperiodicityTimeBaseOfSpeakerA',qA.temporalPositions);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'aperiodicityOfSpeakerB',qB);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'aperiodicityTimeBaseOfSpeakerB',qB.temporalPositions);

%%  read label file and assign temporal anchor points

%labelA = readAudacityLabel('../ANNYSTRAIGHT/testData/aiueoLlbl.txt');
%labelB = readAudacityLabel('../ANNYSTRAIGHT/testData/aiueoF2lbl.txt');
labelA = readAudacityLabel('aiueoLlbl.txt');
labelB = readAudacityLabel('aiueoF2lbl.txt');

mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'temporaAnchorOfSpeakerA',labelA.segment(:,1));
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'temporaAnchorOfSpeakerB',labelB.segment(:,1));

upperLimitOfFrequencyAnchors = 6;
frequencyAnchorOfSpeakerA.frequency = ...
    zeros(size(labelA.segment,1),upperLimitOfFrequencyAnchors);
frequencyAnchorOfSpeakerA.counts = zeros(size(labelA.segment,1),1);
frequencyAnchorOfSpeakerB.frequency = ...
    zeros(size(labelB.segment,1),upperLimitOfFrequencyAnchors);
frequencyAnchorOfSpeakerB.counts = zeros(size(labelB.segment,1),1);
if size(labelA.segment,1) ~= size(labelB.segment,1)
    disp('number of temporal anchors has to be the same.')
    return;
end;
for ii = 1:size(labelA.segment,1)
    for jj = 1:upperLimitOfFrequencyAnchors
        markA = -500+jj*1000-50;
        markB = -500+jj*1000+50;
        frequencyAnchorOfSpeakerA.frequency(ii,jj) = markA;
        frequencyAnchorOfSpeakerB.frequency(ii,jj) = markB;
    end;
end;
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'frequencyAnchorOfSpeakerA',frequencyAnchorOfSpeakerA);
mSubstrate = morphingSubstrateNewAP(mSubstrate,'set',...
    'frequencyAnchorOfSpeakerB',frequencyAnchorOfSpeakerB);

%%  display spectrogram and temporal anchors

displaySpec.upperFrequency = 6000;
displaySpec.displayAttribute = 'spectrogram';
displaySpec.spectralDynamicRange = 70; % in dB
displaySpec.itemToBeDisplayed = 'speakerA';
displayMorphingSubstrate(mSubstrate,displaySpec);
displaySpec.upperFrequency = 6000;
displaySpec.displayAttribute = 'spectrogram';
displaySpec.spectralDynamicRange = 70; % in dB
displaySpec.itemToBeDisplayed = 'speakerB';
displayMorphingSubstrate(mSubstrate,displaySpec);

%%  generate common time axis form morphing with variable rates

mRateCommon = 1; %0:0.2:1
mSubstrate = morphingSubstrateNewAP(mSubstrate,'generate','morphingTimeAxis',mRateCommon);

figure;
plot(mSubstrate.anchorOnMorphingTime,mSubstrate.temporaAnchorOfSpeakerA,'-o', ...
    mSubstrate.anchorOnMorphingTime,mSubstrate.temporaAnchorOfSpeakerB,'-s', ...
    mSubstrate.anchorOnMorphingTime,mSubstrate.anchorOnMorphingTime);grid on;
title(['morping rate of reference: ' num2str(mRateCommon)]);
xlabel('time on the reference axis (s)')
ylabel('time on each axis (s)')

%%  define temporally variable morphing rate on the morphing time axis

%   first of all, try the simplest one

fs = mSubstrate.samplintFrequency;

mRate.time = 0-0.5*(mSubstrate.morphingTimeAxis(:))/mSubstrate.morphingTimeAxis(end);
mRate.F0 = mRate.time;
mRate.frequency = mRate.time;
mRate.spectrum = mRate.time;
mRate.aperiodicity = mRate.time;

mSubstrate = morphingSubstrateNewAP(mSubstrate,'set','temporalMorphingRate',mRate);

%%  calculate only for display purpose


mSubstrate = morphingSubstrateNewAP(mSubstrate,'generate','realTimeAxis');

%  test time axis morphing

figure;plot(mSubstrate.realTimeBase.timeOnM,mSubstrate.realTimeBase.mapMtoAonM, ...
    mSubstrate.realTimeBase.timeOnM,mSubstrate.realTimeBase.mapMtoBonM, ...
    mSubstrate.realTimeBase.timeOnM,mSubstrate.realTimeBase.mapMtoSonM);grid on;
set(gca,'fontsize',14);
xlabel('time on the reference axis (s)')
ylabel('time on each axis (s)')

%   view morphed parameters
%   This part is for debugging
%   Calculating the following line is not necessary 

mSubstrate = morphingSubstrateNewAP(mSubstrate,'generate','morphedDisplayParameters');
figure;
set(gcf,'position',[260 130 880 660])
subplot(221);semilogy(mSubstrate.f0TimeBaseOfSpeakerA,mSubstrate.f0OfSpeakerA);grid on;
axis([0 mSubstrate.f0TimeBaseOfSpeakerA(end) 40 800]);
subplot(223);semilogy(mSubstrate.f0TimeBaseOfSpeakerB,mSubstrate.f0OfSpeakerB);grid on;
axis([0 mSubstrate.f0TimeBaseOfSpeakerB(end) 40 800]);
subplot(222);plot(mSubstrate.morphingTimeAxis,mSubstrate.temporalMorphingRate.time);grid on;
axis([0 mSubstrate.morphingTimeAxis(end) 0 1]);
subplot(224);semilogy(mSubstrate.morphedDisplayRealTime,mSubstrate.morphedDisplayF0);grid on;
axis([0 mSubstrate.morphedDisplayRealTime(end) 40 800]);

%figure;imagesc(log(mSubstrate.morphedDisplayspectrum));axis('xy');
%axis([0 size(mSubstrate.morphedDisplayspectrum,2) 0 200])

%  make spectrogram for display

morphedSgramIndB = 10*log10(mSubstrate.morphedDisplayspectrum);
maxDB = max(max(morphedSgramIndB));
fx = (0:size(morphedSgramIndB,1)-1)/(size(morphedSgramIndB,1)-1)/2*fs;
tx = 0.005*size(morphedSgramIndB,2);
figure;imagesc([0 tx],[0 fs/2],max(maxDB-70,morphedSgramIndB));
axis('xy');
axis([0 tx 0 6000])
set(gca,'fontsize',18);
xlabel('time on the real time (s)')
ylabel('frequency (Hz)')
title('morphed STRAIGHT spectrogram');
%%  generate morphed speech and play

morphedSignal = generateMorphedSpeechNewAP(mSubstrate)

soundsc(morphedSignal.outputBuffer,fs)

return;
%%  The following cells are for incremental morphing  
%
%   generate incremental time axis

for fixMrate = 0%:0.2:1
    tic
    deltaTonSynthAxis = 0.005; % 5ms in second
    timeOnSynthAxis = 0:deltaTonSynthAxis:2*max([mSubstrate.f0TimeBaseOfSpeakerA(end),...
        mSubstrate.f0TimeBaseOfSpeakerB(end)]);
    mRateTimeOnSynthAxis = min(1,fixMrate+1*timeOnSynthAxis/min([mSubstrate.f0TimeBaseOfSpeakerA(end),...
        mSubstrate.f0TimeBaseOfSpeakerB(end)]));

    t_A = 0;
    t_B = 0;

    extendedAnchorOnA = [0;mSubstrate.temporaAnchorOfSpeakerA; ...
        mSubstrate.f0TimeBaseOfSpeakerA(end)];
    extendedAnchorOnB = [0;mSubstrate.temporaAnchorOfSpeakerB; ...
        mSubstrate.f0TimeBaseOfSpeakerB(end)];

    timeAxisOnA = mSubstrate.f0TimeBaseOfSpeakerA;
    timeAxisOnB = mSubstrate.f0TimeBaseOfSpeakerB;
    timeOnBbyAtoBconversion = interp1(extendedAnchorOnA,extendedAnchorOnB,...
        timeAxisOnA,'linear','extrap');
    timeOnAbyBtoAconversion = interp1(extendedAnchorOnB,extendedAnchorOnA,...
        timeAxisOnB,'linear','extrap');
    %   calculate derivatives
    diffConversionAtoB = diff(timeOnBbyAtoBconversion(:))./diff(timeAxisOnA(:));
    diffConversionAtoB = [diffConversionAtoB(1);diffConversionAtoB];
    diffConversionBtoA = diff(timeOnAbyBtoAconversion(:))./diff(timeAxisOnB(:));
    diffConversionBtoA = [diffConversionBtoA(1);diffConversionBtoA];
    %   prepare PP (piecewise polynomial) for interpolation
    ppForDiffAtoB = interp1(timeAxisOnA,diffConversionAtoB,'linear','pp');
    ppForDiffBtoA = interp1(timeAxisOnB,diffConversionBtoA,'linear','pp');
    realTimeOnA = zeros(length(timeOnSynthAxis),1);
    realTimeOnB = zeros(length(timeOnSynthAxis),1);
    for ii = 1:length(timeOnSynthAxis)
        if (t_A > mSubstrate.f0TimeBaseOfSpeakerA(end))||(t_B > mSubstrate.f0TimeBaseOfSpeakerB(end))
            break;
        end;
        t_s = timeOnSynthAxis(ii);
        dt_A = 1/(1+mRateTimeOnSynthAxis(ii)*(ppval(ppForDiffAtoB,t_A)-1));
        t_A = t_A + dt_A*deltaTonSynthAxis;
        realTimeOnA(ii) = t_A;
        dt_B = 1/(1+(1-mRateTimeOnSynthAxis(ii))*(ppval(ppForDiffBtoA,t_B)-1));
        t_B = t_B + dt_B*deltaTonSynthAxis;
        realTimeOnB(ii) = t_B;
    end;
    toc
    figure;plot(timeOnSynthAxis(1:ii-1),realTimeOnA(1:ii-1),timeOnSynthAxis(1:ii-1),realTimeOnB(1:ii-1),...
        timeOnSynthAxis(1:ii-1),timeOnSynthAxis(1:ii-1));grid on;

end;

%%  generate incremental time axis with non-negative morphing

for fixMrate = 0:0.2:1
    tic
    deltaTonSynthAxis = 0.005; % 5ms in second
    timeOnSynthAxis = 0:deltaTonSynthAxis:2*max([mSubstrate.f0TimeBaseOfSpeakerA(end),...
        mSubstrate.f0TimeBaseOfSpeakerB(end)]);
    mRateTimeOnSynthAxis = min(1,fixMrate+0*timeOnSynthAxis/min([mSubstrate.f0TimeBaseOfSpeakerA(end),...
        mSubstrate.f0TimeBaseOfSpeakerB(end)]));

    t_A = 0;
    t_B = 0;

    extendedAnchorOnA = [0;mSubstrate.temporaAnchorOfSpeakerA; ...
        mSubstrate.f0TimeBaseOfSpeakerA(end)];
    extendedAnchorOnB = [0;mSubstrate.temporaAnchorOfSpeakerB; ...
        mSubstrate.f0TimeBaseOfSpeakerB(end)];

    timeAxisOnA = mSubstrate.f0TimeBaseOfSpeakerA;
    timeAxisOnB = mSubstrate.f0TimeBaseOfSpeakerB;
    timeOnBbyAtoBconversion = interp1(extendedAnchorOnA,extendedAnchorOnB,...
        timeAxisOnA,'linear','extrap');
    timeOnAbyBtoAconversion = interp1(extendedAnchorOnB,extendedAnchorOnA,...
        timeAxisOnB,'linear','extrap');
    %   calculate derivatives
    diffConversionAtoB = diff(timeOnBbyAtoBconversion(:))./diff(timeAxisOnA(:));
    diffConversionAtoB = [diffConversionAtoB(1);diffConversionAtoB];
    diffConversionBtoA = diff(timeOnAbyBtoAconversion(:))./diff(timeAxisOnB(:));
    diffConversionBtoA = [diffConversionBtoA(1);diffConversionBtoA];
    %   prepare PP (piecewise polynomial) for interpolation
    ppForDiffAtoB = interp1(timeAxisOnA,diffConversionAtoB,'linear','pp');
    ppForDiffBtoA = interp1(timeAxisOnB,diffConversionBtoA,'linear','pp');
    realTimeOnA = zeros(length(timeOnSynthAxis),1);
    realTimeOnB = zeros(length(timeOnSynthAxis),1);
    for ii = 1:length(timeOnSynthAxis)
        if (t_A > mSubstrate.f0TimeBaseOfSpeakerA(end))||(t_B > mSubstrate.f0TimeBaseOfSpeakerB(end))
            break;
        end;
        t_s = timeOnSynthAxis(ii);
        %dt_A = 1/exp(mRateTimeOnSynthAxis(ii)*log(ppval(ppForDiffAtoB,t_A)));
        dt_A = ppval(ppForDiffAtoB,t_A)^(-mRateTimeOnSynthAxis(ii));
        t_A = t_A + dt_A*deltaTonSynthAxis;
        realTimeOnA(ii) = t_A;
        %dt_B = 1/exp((1-mRateTimeOnSynthAxis(ii))*log(ppval(ppForDiffBtoA,t_B)));
        dt_B = ppval(ppForDiffBtoA,t_B)^(mRateTimeOnSynthAxis(ii)-1);
        t_B = t_B + dt_B*deltaTonSynthAxis;
        realTimeOnB(ii) = t_B;
    end;
    toc
    figure;plot(timeOnSynthAxis(1:ii-1),realTimeOnA(1:ii-1),...
        timeOnSynthAxis(1:ii-1),realTimeOnB(1:ii-1),...
        timeOnSynthAxis(1:ii-1),timeOnSynthAxis(1:ii-1));grid on;
    drawnow;
end;


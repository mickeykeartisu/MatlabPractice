function displayMorphingSubstrate(mSubstrate,displaySpec)

%displaySpec.upperFrequency = 6000;
%displaySpec.displayAttribute = 'spectrogram';
%displaySpec.itemToBeDisplayed = 'speakerA';
fs = mSubstrate.samplintFrequency;
upperFrequencyLimit = 6000;

switch displaySpec.displayAttribute
    case 'spectrogram'
        switch displaySpec.itemToBeDisplayed
            case 'speakerA'
                timeAxis = mSubstrate.spectrogramTimeBaseOfSpeakerA;
                sgramSTRAIGHT = mSubstrate.STRAIGHTspectrogramOfSpeakerA;
                if ~isempty(mSubstrate.temporaAnchorOfSpeakerA)
                    temporalAnchor = mSubstrate.temporaAnchorOfSpeakerA;
                end;
            case 'speakerB'
                timeAxis = mSubstrate.spectrogramTimeBaseOfSpeakerB;
                sgramSTRAIGHT = mSubstrate.STRAIGHTspectrogramOfSpeakerB;
                if ~isempty(mSubstrate.temporaAnchorOfSpeakerA)
                    temporalAnchor = mSubstrate.temporaAnchorOfSpeakerB;
                end;
        end;
        sgramSTRAIGHT = 10*log10(sgramSTRAIGHT);
        sgramSTRAIGHT = max(max(max(sgramSTRAIGHT))...
            -displaySpec.spectralDynamicRange, sgramSTRAIGHT);
        figure;imagesc([0 timeAxis(end)],[0 fs/2], ...
            sgramSTRAIGHT);axis('xy');
        hold on
        for ii = 1:length(temporalAnchor)
            plot(temporalAnchor(ii)*[1 1],[0 fs/2],'w');
            text(temporalAnchor(ii),upperFrequencyLimit*1.02,...
                char(rem(ii-1,26)+1+64));
        end;
        axis([0 timeAxis(end) 0 upperFrequencyLimit]);
        set(gca,'fontsize',13);
        xlabel(['time (s) of '  displaySpec.itemToBeDisplayed])
        ylabel('frequency (Hz)');
        %title(displaySpec.itemToBeDisplayed);
        hold off
        drawnow;
    otherwise
        display('nothing to do.')
        return;
end;
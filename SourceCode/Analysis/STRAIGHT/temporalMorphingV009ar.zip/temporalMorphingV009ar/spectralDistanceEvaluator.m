function distanceStructure = ...
    spectralDistanceEvaluator(spectrumA,spectrumB,samplingFrequency,kind)

distanceStructure = [];
if size(spectrumA) ~= size(spectrumB)
    disp('Input vectors has to have the same size');
    return;
end;
switch kind
    case 'power'
        pwA = spectrumA(:);
        pwB = spectrumB(:);
    case 'dB'
        pwA = 10.0.^(spectrumA(:)/10);
        pwB = 10.0.^(spectrumB(:)/10);
    case 'complex'
        pwA = abs(spectrumA(:)).^2;
        pwB = abs(spectrumB(:)).^2;
    otherwise
        disp('kind has to be one of: power, dB and complex');
        return;
end;
AindB = 10*log10(pwA);
BindB = 10*log10(pwB);

%   input is OK. then initialize

distanceStructure.lineardB = std(AindB-BindB);

fs = samplingFrequency;
fftl = (size(spectrumA(:),1)-1)*2;
frequencyAxis = (0:fftl/2)'/fftl*fs;
ERBaxis = 21.4*log10(frequencyAxis*0.00437+1);
ERBweight = 21.4/log(10)./(0.00437*frequencyAxis+1);

differenceVector = AindB-BindB;
weigtedDifference = ERBweight.*differenceVector;
ERBdistance = sum(ERBweight.*(differenceVector-sum(weigtedDifference)/sum(ERBweight)).^2)/sum(ERBweight);
distanceStructure.ERBdistance = sqrt(ERBdistance);

nTerm = 2;
normalizedERBaxis = pi*(ERBaxis-ERBaxis(1))/(ERBaxis(end)-ERBaxis(1));
cosBasisFunction = zeros(length(ERBaxis),nTerm);
for ii = 1:nTerm
    cosBasisFunction(:,ii) = cos(ii*normalizedERBaxis(:));
end;
coefficients = (ERBweight.*(differenceVector-sum(weigtedDifference)/sum(ERBweight)))'*cosBasisFunction;
coefficientsNormal = coefficients/sum(ERBweight);
smoothedDifference = ...
    2*sum((cosBasisFunction(:,1:nTerm)*diag(coefficientsNormal(1:nTerm)))');
fixedDifference = (differenceVector-sum(weigtedDifference)/sum(ERBweight))-smoothedDifference';
fixedERBDistance = sum(ERBweight.*fixedDifference.^2)/sum(ERBweight);
distanceStructure.fixedERBDistance = sqrt(fixedERBDistance);

normalERBaxis = (ERBaxis-ERBaxis(1))/(ERBaxis(end)-ERBaxis(1));
nChannels = 20;
mfccFilter = zeros(fftl/2+1,nChannels+1);
for ii = 1:nChannels+1
    centerERB = (ii-1)/nChannels;
    mfccFilter(:,ii) = max(0,1-abs(normalERBaxis-centerERB)*nChannels);
end;
correctionFactor = sum(sum(mfccFilter));
mfccA = AindB'*mfccFilter/correctionFactor;
mfccB = BindB'*mfccFilter/correctionFactor;
distanceStructure.mfcc = std(mfccA-mfccB);

mfccWeight = (1:nChannels+1)';
mfccA = AindB'*mfccFilter/correctionFactor;
mfccB = BindB'*mfccFilter/correctionFactor;
distanceStructure.weightedMfcc = sum(mfccWeight'.* ...
    (mfccA-mfccB-mean(mfccA-mfccB)).^2)/sum(mfccWeight);

return;

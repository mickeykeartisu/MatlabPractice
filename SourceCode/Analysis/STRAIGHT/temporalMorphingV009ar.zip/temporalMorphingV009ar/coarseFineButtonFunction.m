function coarseFineButtonFunction

objectHandel = gco;
buttonName = get(objectHandel,'tag');
switch buttonName
    case 'coarseButton'
        set(findobj('tag','coarseButton'),'value',1);
        set(findobj('tag','fineButton'),'value',0);
    case 'fineButton'
        set(findobj('tag','coarseButton'),'value',0);
        set(findobj('tag','fineButton'),'value',1);
end;
figureHandle = findobj('tag','figure1');
figureUserdata = get(figureHandle,'userdata');
objectHandles = figureUserdata.handleInfo;
axisUserData = get(objectHandles.SpectralSection,'userdata');
focus = axisUserData.focus;
%if focus == 0
%    focus = 1;
%end;
set(figureHandle,'currentobject',axisUserData.frequencyPointObj.lineAHandle(focus));
frequencyAnchorCallback;

function revisedF0str = reviseF0candidate(f0Structure,regionLimit)

timeAxis = f0Structure.temporalPositions;
f0Frequency = f0Structure.f0CandidatesMap;
f0Score = f0Structure.f0CandidatesScoreMap;
timeIndex = 1:length(timeAxis);
revisedF0str = f0Structure;

timeMin = regionLimit(1);
timeMax = regionLimit(2);
f0Min = regionLimit(3);
f0Max = regionLimit(4);

nCandidates = size(f0Score,1);

regionIndex = timeIndex((timeAxis>timeMin)&(timeAxis<timeMax));

for ii = 1:length(regionIndex)
    jj = regionIndex(ii);
    tmpF0Score = f0Score(:,jj);
    for kk = 1:nCandidates
        if (f0Frequency(kk,jj)>f0Min)&(f0Frequency(kk,jj)<f0Max)
            tmpF0Score(kk) = tmpF0Score(kk)+2;
        end;
    end;
    [dummy,sortedIndex] = sort(tmpF0Score,'descend');
    f0Score(:,jj) = f0Score(sortedIndex,jj);
    f0Frequency(:,jj) = f0Frequency(sortedIndex,jj);
end;
revisedF0str.f0CandidatesMap = f0Frequency;
revisedF0str.f0CandidatesScoreMap = f0Score;
revisedF0str.f0 = f0Frequency(1,:)';




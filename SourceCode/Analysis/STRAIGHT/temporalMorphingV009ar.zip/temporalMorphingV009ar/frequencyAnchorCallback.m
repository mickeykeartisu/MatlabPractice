%%% supporting function

function frequencyAnchorCallback(varargin)

if size(varargin,2) > 0
    objectHandel = varargin{:};
    insideEvent = 0;
else
    objectHandel = gco;
    insideEvent = 1;
end;
if strcmp(get(objectHandel,'tag'),'frequencyAnchors')
    objectUserData = get(objectHandel,'userdata');
    anchorNumber = objectUserData{1};
    %disp(['Yes! frequency anchor' num2str(anchorNumber)])
    parentAxisHandle = get(objectHandel,'parent');
    axisUserData = get(parentAxisHandle,'userdata');
    parentFigureHandle = get(parentAxisHandle,'parent');
    figureUserData = get(parentFigureHandle,'userdata');
    anchorIndex = figureUserData.selectedItem;
    objectHandles = figureUserData.handleInfo;
    set(objectHandles.FrequencyAdjustA,'userdata',objectHandel,'visible','on');
    set(objectHandles.FrequencyAdjustB,'userdata',objectHandel,'visible','on');
    set(objectHandles.FrequencyA,'visible','on');
    set(objectHandles.FrequencyB,'visible','on');
    %set(objectHandles.frequencyAnchors,'value',1);
    mSubstrate = figureUserData.inputData;
    if (anchorNumber == axisUserData.focus) && (anchorNumber>0) && (insideEvent == 1)
        xdata = get(axisUserData.frequencyPointObj.markAHandle(anchorNumber),'xdata');
        figureUserData.inputData.frequencyAnchorOfSpeakerA.frequency(anchorIndex,anchorNumber) ...
            = xdata(1);
        xdata = get(axisUserData.frequencyPointObj.markBHandle(anchorNumber),'xdata');
        figureUserData.inputData.frequencyAnchorOfSpeakerB.frequency(anchorIndex,anchorNumber) ...
            = xdata(1);
        set(parentFigureHandle,'userdata',figureUserData);
        mSubstrate = figureUserData.inputData;
    elseif axisUserData.focus > 0
        set(axisUserData.frequencyPointObj.markAHandle(axisUserData.focus), ...
            'xdata',mSubstrate.frequencyAnchorOfSpeakerA.frequency(anchorIndex,axisUserData.focus));
        set(axisUserData.frequencyPointObj.markBHandle(axisUserData.focus), ...
            'xdata',mSubstrate.frequencyAnchorOfSpeakerB.frequency(anchorIndex,axisUserData.focus));
        set(axisUserData.frequencyPointObj.lineAHandle(axisUserData.focus), ...
            'xdata',mSubstrate.frequencyAnchorOfSpeakerA.frequency(anchorIndex,axisUserData.focus)*[1 1]);
        set(axisUserData.frequencyPointObj.lineBHandle(axisUserData.focus), ...
            'xdata',mSubstrate.frequencyAnchorOfSpeakerB.frequency(anchorIndex,axisUserData.focus)*[1 1]);
    end;
    fs = mSubstrate.samplintFrequency;
    fftl = (size(mSubstrate.STRAIGHTspectrogramOfSpeakerA,1)-1)*2;
    %fx = (0:size(mSubstrate.STRAIGHTspectrogramOfSpeakerA,1)-1)/fftl*fs;
    deltaF = fs/fftl;
    [dmy,iTimeA] = min(abs(mSubstrate.spectrogramTimeBaseOfSpeakerA- ...
        mSubstrate.temporaAnchorOfSpeakerA(anchorIndex)));
    [dmy,iTimeB] = min(abs(mSubstrate.spectrogramTimeBaseOfSpeakerB- ...
        mSubstrate.temporaAnchorOfSpeakerB(anchorIndex)));
    nFormants = mSubstrate.frequencyAnchorOfSpeakerA.counts(figureUserData.selectedItem);
    %axisUserData.frequencyPointObj
    lineAHandle = axisUserData.frequencyPointObj.lineAHandle;
    lineBHandle = axisUserData.frequencyPointObj.lineBHandle;
    markAHandle = axisUserData.frequencyPointObj.markAHandle;
    markBHandle = axisUserData.frequencyPointObj.markBHandle;
    for ii = nFormants+1:6
        set(lineAHandle(ii),'visible','off');
        set(lineBHandle(ii),'visible','off');
        set(markAHandle(ii),'visible','off');
        set(markBHandle(ii),'visible','off');
    end;
    logSpecA = 10*log10(mSubstrate.STRAIGHTspectrogramOfSpeakerA(:,iTimeA));
    logSpecB = 10*log10(mSubstrate.STRAIGHTspectrogramOfSpeakerB(:,iTimeB));
    for ii = 1:nFormants
        markA = mSubstrate.frequencyAnchorOfSpeakerA.frequency(anchorIndex,ii);
        markB = mSubstrate.frequencyAnchorOfSpeakerB.frequency(anchorIndex,ii);
        levelA = logSpecA(round(markA/deltaF)+1);
        levelB = logSpecB(round(markB/deltaF)+1);
        set(lineAHandle(ii),'xdata',markA*[1 1],'visible','on');
        set(lineBHandle(ii),'xdata',markB*[1 1],'visible','on');
        set(markAHandle(ii),'xdata',markA,'ydata',levelA,'visible','off');
        set(markBHandle(ii),'xdata',markB,'ydata',levelB,'visible','off');
    end;
    if nFormants > 0
        markA = mSubstrate.frequencyAnchorOfSpeakerA.frequency(anchorIndex,anchorNumber);
        markB = mSubstrate.frequencyAnchorOfSpeakerB.frequency(anchorIndex,anchorNumber);
        levelA = logSpecA(round(markA/deltaF)+1);
        levelB = logSpecB(round(markB/deltaF)+1);
        set(markAHandle(anchorNumber),'visible','on','xdata',markA,'ydata',levelA);
        set(markBHandle(anchorNumber),'visible','on','xdata',markB,'ydata',levelB);
        set(objectHandles.FrequencyA,'visible','on','string',num2str(round(markA),'%6d'));
        set(objectHandles.FrequencyB,'visible','on','string',num2str(round(markB),'%6d'));
        set(objectHandles.FrequencyForA,'visible','on');
        set(objectHandles.FrequencyForB,'visible','on');
        set(objectHandles.fineButton,'visible','on');
        set(objectHandles.coarseButton,'visible','on');
        set(objectHandles.frequencyAdjustGroup,'visible','on');
        axisUserData.focus = anchorNumber;
    else
        set(objectHandles.FrequencyAdjustA,'visible','off');
        set(objectHandles.FrequencyAdjustB,'visible','off');
        set(objectHandles.FrequencyA,'visible','off');
        set(objectHandles.FrequencyB,'visible','off');
        set(objectHandles.FrequencyForA,'visible','off');
        set(objectHandles.FrequencyForB,'visible','off');
        set(objectHandles.fineButton,'visible','off');
        set(objectHandles.coarseButton,'visible','off');
        set(objectHandles.frequencyAdjustGroup,'visible','off');
        axisUserData.focus = 0;
    end;
    axisUserData.numberOfFrequencyAnchors = nFormants;
    axisUserData.temporalAnchorID = anchorIndex;
    set(parentAxisHandle,'userdata',axisUserData);
    set(objectHandles.FrequencyAdjustA,'value',0);
    set(objectHandles.FrequencyAdjustB,'value',0);
    resultsStr = frequencyAnchorEvaluation;
    %set(axisUserData.logSpecBonAHandle,'ydata',resultsStr.logSpecBonA);
    %set(objectHandles.ERBdBView,'string',num2str(resultsStr.erbDBdistortion,'%5.2f'));
    set(axisUserData.logSpecBonAHandle,'ydata',resultsStr.modifiedBonA);
    set(objectHandles.ERBdBView,'string',num2str(resultsStr.modifiedERBdistortion,'%5.2f'));
else
    disp('this is not a frequency anchors')
end;

%%%---- supporting internal function


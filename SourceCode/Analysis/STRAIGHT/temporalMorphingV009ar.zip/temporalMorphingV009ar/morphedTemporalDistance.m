function temporalDistanceList = morphedTemporalDistance(mSubstrate)

%   Designed and coded by Hideki Kawahara
%   19/Sept./2008

%   Distance is calculated on one of the axis
%   (This can be extended to symmetrical measure.)

%   generate morphed temporal axis in sampling rate resolution

fs = mSubstrate.samplintFrequency;
samplingPoints = 0:1/fs:mSubstrate.realTimeBase.mapMtoSonM(end);
outputBuffer = 0*samplingPoints';

%   generate interpolated f0 information to set event location

lengthTimeOnM = length(mSubstrate.realTimeBase.mapMtoAonM);
morphedF0onM = zeros(lengthTimeOnM,1);
F0ofAonA = interp1(mSubstrate.f0TimeBaseOfSpeakerA,mSubstrate.f0OfSpeakerA, ...
    mSubstrate.realTimeBase.mapMtoAonM,'linear','extrap');
F0ofBonB = interp1(mSubstrate.f0TimeBaseOfSpeakerB,mSubstrate.f0OfSpeakerB, ...
    mSubstrate.realTimeBase.mapMtoBonM,'linear','extrap');
for ii = 1:lengthTimeOnM
    morphedF0onM(ii) = (1-mSubstrate.temporalMorphingRate.F0(ii))* ...
        F0ofAonA(ii)+mSubstrate.temporalMorphingRate.F0(ii)*F0ofBonB(ii);
end;
f0onSamplingPoints = interp1(mSubstrate.realTimeBase.mapMtoSonM, ...
    morphedF0onM,samplingPoints,'linear','extrap');
totalPhase = cumsum(f0onSamplingPoints*2*pi/fs);
basePhase = 0;
eventCount = 0;
eventLocations = f0onSamplingPoints*0;
eventTime = eventLocations;
for ii = 1:length(f0onSamplingPoints)
    if totalPhase(ii)-basePhase>2*pi
        basePhase = basePhase+2*pi;
        fractionalPhase = totalPhase(ii)-basePhase;
        %outputBuffer(ii) = 1;
        eventCount = eventCount+1;
        eventLocations(eventCount) = ii + fractionalPhase/(2*pi/fs*f0onSamplingPoints(ii));
        eventTime(eventCount) = samplingPoints(ii);
    end;
end;
eventLocations = mSubstrate.spectrogramTimeBaseOfSpeakerA;%%
eventCount = length(eventLocations);
eventTime = eventTime(1:eventCount);
eventTimeOnM = interp1(mSubstrate.realTimeBase.mapMtoSonM,mSubstrate.realTimeBase.timeOnM,eventTime,'linear','extrap');
eventTimeOnA = interp1(mSubstrate.realTimeBase.timeOnM,mSubstrate.realTimeBase.mapMtoAonM,eventTimeOnM,'linear','extrap');
eventTimeOnB = interp1(mSubstrate.realTimeBase.timeOnM,mSubstrate.realTimeBase.mapMtoBonM,eventTimeOnM,'linear','extrap');
frequencyMorphingRateOnEvent = interp1(mSubstrate.realTimeBase.mapMtoSonM,...
    mSubstrate.temporalMorphingRate.frequency,eventTime,'linear','extrap');
levelMorphingRateOnEvent = interp1(mSubstrate.realTimeBase.mapMtoSonM,...
    mSubstrate.temporalMorphingRate.spectrum,eventTime,'linear','extrap');
spectumAonEvnet = interp1(mSubstrate.spectrogramTimeBaseOfSpeakerA, ...
    (mSubstrate.STRAIGHTspectrogramOfSpeakerA)',eventTimeOnA,'linear','extrap')';
spectumBonEvnet = interp1(mSubstrate.spectrogramTimeBaseOfSpeakerB, ...
    (mSubstrate.STRAIGHTspectrogramOfSpeakerB)',eventTimeOnB,'linear','extrap')';
numberOfTimeAnchors = length(mSubstrate.temporaAnchorOfSpeakerA);
frequencyMappingForAtoB = zeros(size(spectumAonEvnet,1),numberOfTimeAnchors);
%   note that this mapping is a linear lintepolation. This should be
%   replaced
frequencyAxis = (0:size(spectumAonEvnet,1)-1)/(size(spectumAonEvnet,1)-1)*fs/2;
for ii = 1:numberOfTimeAnchors
    if mSubstrate.frequencyAnchorOfSpeakerA.counts(ii) > 0
        counts = mSubstrate.frequencyAnchorOfSpeakerA.counts(ii);
        extendedFrequencyAnchorsA = [0 mSubstrate.frequencyAnchorOfSpeakerA.frequency(ii,1:counts) fs/2];
        extendedFrequencyAnchorsB = [0 mSubstrate.frequencyAnchorOfSpeakerB.frequency(ii,1:counts) fs/2];
    else
        extendedFrequencyAnchorsA = [0 fs/2];
        extendedFrequencyAnchorsB = [0 fs/2];
    end;
    frequencyMappingForAtoB(:,ii) = ...
        interp1(extendedFrequencyAnchorsA,extendedFrequencyAnchorsB,frequencyAxis,'linear','extrap');
end;

fftl = (size(spectumAonEvnet,1)-1)*2;
baseIndex = ((1:fftl)-fftl/2-1)';
maxIndex = length(outputBuffer);
morphedSpectrumOnEvent = spectumAonEvnet*0;
morphedFrequencyMapping = morphedSpectrumOnEvent;
%figure;
distances = zeros(eventCount,6);
tocList = zeros(eventCount,1);
for ii = 1:eventCount
    currentFrequencyMappingAtoB = ...
        interp1([0;mSubstrate.temporaAnchorOfSpeakerA;mSubstrate.spectrogramTimeBaseOfSpeakerA(end)]...
        ,[frequencyAxis(:),frequencyMappingForAtoB,frequencyAxis(:)]',...
        eventTimeOnA(ii),'linear','extrap');
    morphedFrequencyMappingAtoB = frequencyAxis(:)+ ...
        (currentFrequencyMappingAtoB(:)-frequencyAxis(:))*frequencyMorphingRateOnEvent(ii);
    currentIndex = max(1,min(maxIndex,round(baseIndex+eventLocations(ii))));
    morphedFrequencyMapping(:,ii) = currentFrequencyMappingAtoB;
    spectrumA = log(abs(spectumAonEvnet(:,ii)));
    spectrumB = log(abs(spectumBonEvnet(:,ii)));
    spectrumBonA = interp1(frequencyAxis,spectrumB,currentFrequencyMappingAtoB(:),'linear','extrap');
    %semilogx(frequencyAxis,spectrumA,frequencyAxis,real(spectrumBonA),frequencyAxis,spectrumB);grid on;
    %title(num2str(eventTime(ii)));
    %axis([100 fs/2 -15 10])
    %drawnow;%pause(0.2)
    tic;
    distanceStructure = spectralDistanceEvaluator(exp(spectrumA),exp(spectrumBonA),fs,'power');
    tocList(ii) = toc;
    distances(ii,1:4) = [distanceStructure.ERBdistance, ...
        distanceStructure.fixedERBDistance, ...
        distanceStructure.mfcc, distanceStructure.weightedMfcc];
%    morphedSpectrumOnA = exp((1-levelMorphingRateOnEvent(ii))*spectrumA+...
%        levelMorphingRateOnEvent(ii)*real(spectrumBonA));
%    morphedSpectrum = interp1(morphedFrequencyMappingAtoB,morphedSpectrumOnA,frequencyAxis(:),'linear','extrap');
%    firResponse = fftshift(real(ifft(sqrt([morphedSpectrum; ...
%        morphedSpectrum(end-1:-1:2)]))));
%    morphedSpectrumOnEvent(:,ii) = morphedSpectrum;
%    outputBuffer(currentIndex) = outputBuffer(currentIndex)+firResponse;
end;

temporalDistanceList.distances = distances;
temporalDistanceList.temporalPositions = eventLocations;
temporalDistanceList.elapsedTime = tocList;
%   output results
%morphedSignal.f0onSamplingPoints = f0onSamplingPoints;
%morphedSignal.outputBuffer = outputBuffer;
%morphedSignal.eventLocations = eventLocations;
%morphedSignal.spectumAonEvnet = spectumAonEvnet;
%morphedSignal.frequencyMappingForAtoB = frequencyMappingForAtoB;
%morphedSignal.frequencyMorphingRateOnEvent = frequencyMorphingRateOnEvent;
%morphedSignal.morphedSpectrumOnEvent = morphedSpectrumOnEvent;
%morphedSignal.morphedFrequencyMapping = morphedFrequencyMapping;
%morphedSignal.samplintFrequency = fs;
